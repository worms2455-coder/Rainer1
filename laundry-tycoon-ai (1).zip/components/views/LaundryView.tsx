
import React, { useState } from 'react';
import { useGame } from '../../context/GameContext';
import { MachineType, MachineState } from '../../types';
import { MACHINE_STATS, UPGRADE_COSTS } from '../../constants';
import { IsoCard } from '../ui/IsoCard';

export const LaundryView: React.FC = () => {
  const { state, dispatch } = useGame();
  const [selectedMachineId, setSelectedMachineId] = useState<string | null>(null);

  const machines = state.machines;

  const handleStart = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    dispatch({ type: 'START_MACHINE', id });
  };

  const handleCollect = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    dispatch({ type: 'COLLECT_MACHINE', id });
  };
  
  const handleUpgrade = (type: 'SPEED' | 'ECO' | 'CAP') => {
      if(selectedMachineId) {
          dispatch({ type: 'UPGRADE_MACHINE', id: selectedMachineId, upgradeType: type});
      }
  }

  const selectedMachine = machines.find(m => m.id === selectedMachineId);

  return (
    <div className="flex flex-col h-full gap-4 pb-20">
      {/* Header Info */}
      <div className="bg-white/60 p-3 rounded-xl flex justify-between items-center backdrop-blur-md shadow-sm border border-white/50">
        <h2 className="text-xl font-black text-slate-800 tracking-tight">ПРАЧЕЧНАЯ</h2>
        <span className="text-sm font-bold bg-blue-100 text-blue-700 px-3 py-1 rounded-full">Машин: {machines.length}</span>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-6 flex-1 overflow-y-auto content-start p-2 pb-24">
        {machines.map(machine => {
            const stats = MACHINE_STATS[machine.type];
            const isSelected = selectedMachineId === machine.id;
            
            // Visual Status
            let statusText = "ГОТОВ";
            let statusColor = "text-slate-500";
            
            if (machine.state === MachineState.RUNNING) {
                statusText = "СТИРКА...";
                statusColor = "text-blue-600";
            } else if (machine.state === MachineState.DONE) {
                statusText = "ЗАБРАТЬ";
                statusColor = "text-green-600";
            } else if (machine.state === MachineState.BROKEN) {
                statusText = "ОШИБКА";
                statusColor = "text-red-600";
            }

            return (
                <IsoCard 
                    key={machine.id} 
                    onClick={() => setSelectedMachineId(machine.id)}
                    className={`relative p-0 flex flex-col items-center overflow-visible transition-all duration-300 ${isSelected ? 'ring-4 ring-blue-400 z-20 scale-105 shadow-2xl' : 'hover:z-10 hover:scale-[1.02]'}`}
                    depth="lg"
                >
                   {/* Realistic Machine SVG */}
                   <div className="w-full aspect-[3/4] p-2 relative">
                       <MachineVisual machine={machine} />
                   </div>

                    {/* Controls Overlay */}
                    <div className="absolute -bottom-3 w-[90%] bg-white/90 backdrop-blur border border-slate-200 shadow-lg rounded-lg p-2 flex flex-col gap-1 items-center z-10">
                         <div className={`text-[10px] font-black uppercase tracking-wider ${statusColor}`}>{statusText}</div>
                         
                         {machine.state === MachineState.IDLE && (
                            <button 
                                onClick={(e) => handleStart(e, machine.id)}
                                className="w-full bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-bold py-1.5 rounded transition-colors shadow-sm"
                            >
                                СТАРТ
                            </button>
                        )}
                        {machine.state === MachineState.DONE && (
                            <button 
                                onClick={(e) => handleCollect(e, machine.id)}
                                className="w-full bg-green-500 hover:bg-green-600 text-white text-[10px] font-bold py-1.5 rounded transition-colors shadow-sm animate-pulse"
                            >
                                +${stats.income}
                            </button>
                        )}
                        {machine.state === MachineState.BROKEN && (
                             <button 
                                onClick={(e) => { e.stopPropagation(); dispatch({ type: 'REPAIR_MACHINE', id: machine.id }); }}
                                className="w-full bg-red-500 hover:bg-red-600 text-white text-[10px] font-bold py-1.5 rounded transition-colors shadow-sm"
                            >
                                ЧИНИТЬ $25
                            </button>
                        )}
                        {machine.state === MachineState.RUNNING && (
                            <div className="w-full bg-slate-200 rounded-full h-1.5 mt-1 overflow-hidden">
                                <div 
                                    className="bg-blue-500 h-full transition-all duration-1000 ease-linear" 
                                    style={{ width: `${(machine.timer / machine.maxTime) * 100}%` }}
                                ></div>
                            </div>
                        )}
                    </div>
                </IsoCard>
            );
        })}
        
        {/* Buy Buttons Section */}
        <div className="col-span-2 md:col-span-3 mt-8 pt-6 border-t border-slate-300/50">
            <h3 className="font-bold text-slate-700 text-sm mb-3 uppercase tracking-wide opacity-70">Магазин оборудования</h3>
            <div className="flex gap-3 overflow-x-auto pb-4 px-1 snap-x">
                <ShopButton type={MachineType.WASHER_BASIC} dispatch={dispatch} money={state.money} />
                <ShopButton type={MachineType.WASHER_PRO} dispatch={dispatch} money={state.money} />
                <ShopButton type={MachineType.WASHER_ULTRA} dispatch={dispatch} money={state.money} />
                <ShopButton type={MachineType.DRYER} dispatch={dispatch} money={state.money} />
                <ShopButton type={MachineType.DRYER_TURBO} dispatch={dispatch} money={state.money} />
            </div>
        </div>
      </div>

      {/* Upgrade Panel */}
      {selectedMachine && (
          <div className="fixed bottom-[85px] left-4 right-4 bg-white/95 backdrop-blur-xl shadow-2xl rounded-2xl p-4 border border-slate-200/50 z-50 animate-in slide-in-from-bottom-10 duration-300">
              <div className="flex justify-between items-center mb-4 border-b border-slate-100 pb-2">
                 <div className="flex items-center gap-2">
                     <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                     <h3 className="font-bold text-slate-800 text-sm uppercase">{MACHINE_STATS[selectedMachine.type].name}</h3>
                 </div>
                 <button onClick={() => setSelectedMachineId(null)} className="bg-slate-100 hover:bg-slate-200 text-slate-500 rounded-full w-6 h-6 flex items-center justify-center font-bold text-xs transition-colors">✕</button>
              </div>
              
              <div className="grid grid-cols-3 gap-3">
                  <UpgradeCard 
                    label="Скорость" 
                    level={selectedMachine.levelSpeed} 
                    cost={UPGRADE_COSTS.SPEED * (selectedMachine.levelSpeed + 1)}
                    color="blue"
                    onClick={() => handleUpgrade('SPEED')}
                    disabled={state.money < UPGRADE_COSTS.SPEED * (selectedMachine.levelSpeed + 1)}
                  />
                  <UpgradeCard 
                    label="Экономия" 
                    level={selectedMachine.levelEco} 
                    cost={UPGRADE_COSTS.ECO * (selectedMachine.levelEco + 1)}
                    color="green"
                    onClick={() => handleUpgrade('ECO')}
                    disabled={state.money < UPGRADE_COSTS.ECO * (selectedMachine.levelEco + 1)}
                  />
                  <UpgradeCard 
                    label="Вместимость" 
                    level={selectedMachine.levelCap} 
                    cost={UPGRADE_COSTS.CAP * (selectedMachine.levelCap + 1)}
                    color="amber"
                    onClick={() => handleUpgrade('CAP')}
                    disabled={state.money < UPGRADE_COSTS.CAP * (selectedMachine.levelCap + 1)}
                  />
              </div>
          </div>
      )}
    </div>
  );
};

const MachineVisual = ({ machine }: { machine: any }) => {
    const isWasher = MACHINE_STATS[machine.type].type === 'washer';
    const isRunning = machine.state === MachineState.RUNNING;
    const isBroken = machine.state === MachineState.BROKEN;
    
    // Washer Colors
    const bodyColor = isWasher ? "#e2e8f0" : "#fff7ed"; // Slate-200 vs Orange-50
    const bodyGradient = isWasher ? "url(#gradWasher)" : "url(#gradDryer)";
    const windowColor = isWasher ? "#3b82f6" : "#f97316";
    
    return (
        <svg viewBox="0 0 100 140" className={`w-full h-full drop-shadow-xl ${isRunning ? 'animate-shake-gentle' : ''}`}>
            <defs>
                <linearGradient id="gradWasher" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" style={{ stopColor: '#cbd5e1', stopOpacity: 1 }} />
                    <stop offset="50%" style={{ stopColor: '#f8fafc', stopOpacity: 1 }} />
                    <stop offset="100%" style={{ stopColor: '#94a3b8', stopOpacity: 1 }} />
                </linearGradient>
                <linearGradient id="gradDryer" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" style={{ stopColor: '#fdba74', stopOpacity: 1 }} />
                    <stop offset="50%" style={{ stopColor: '#fff7ed', stopOpacity: 1 }} />
                    <stop offset="100%" style={{ stopColor: '#fb923c', stopOpacity: 1 }} />
                </linearGradient>
                <filter id="glow">
                    <feGaussianBlur stdDeviation="2.5" result="coloredBlur"/>
                    <feMerge>
                        <feMergeNode in="coloredBlur"/>
                        <feMergeNode in="SourceGraphic"/>
                    </feMerge>
                </filter>
            </defs>
            
            {/* Machine Body (Isometric-ish rounded rect) */}
            <rect x="10" y="10" width="80" height="110" rx="5" fill={bodyGradient} stroke="#64748b" strokeWidth="1" />
            <rect x="10" y="115" width="80" height="5" fill="#475569" /> {/* Base */}
            
            {/* Control Panel Area */}
            <rect x="15" y="15" width="70" height="20" rx="2" fill="#1e293b" />
            
            {/* Digital Display */}
            <rect x="55" y="18" width="25" height="14" fill="#0f172a" />
            <text x="67.5" y="29" textAnchor="middle" fill={isRunning ? "#22c55e" : "#ef4444"} fontSize="8" fontFamily="monospace" fontWeight="bold">
                {isRunning ? `${Math.floor(machine.timer / 60)}:${(machine.timer % 60).toString().padStart(2, '0')}` : isBroken ? "ERR" : "--:--"}
            </text>
            
            {/* Buttons / Knobs */}
            <circle cx="25" cy="25" r="4" fill="#cbd5e1" stroke="#475569" strokeWidth="1" />
            <circle cx="35" cy="25" r="2" fill="#94a3b8" />
            <circle cx="42" cy="25" r="2" fill="#94a3b8" />

            {/* Door Frame */}
            <circle cx="50" cy="75" r="32" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="2" />
            <circle cx="50" cy="75" r="28" fill="#1e293b" />
            
            {/* Glass Window & Internals */}
            <g clipPath="url(#glassClip)">
                <defs>
                    <clipPath id="glassClip">
                        <circle cx="50" cy="75" r="28" />
                    </clipPath>
                </defs>

                {/* Internal Drum Pattern */}
                <g className={isRunning ? "animate-spin-slow origin-[50px_75px]" : ""}>
                    <circle cx="50" cy="75" r="28" fill={isWasher ? "#0f172a" : "#451a03"} />
                    <circle cx="50" cy="75" r="20" fill="none" stroke={isWasher ? "#334155" : "#7c2d12"} strokeWidth="1" strokeDasharray="4 2" />
                    <circle cx="50" cy="75" r="10" fill="none" stroke={isWasher ? "#334155" : "#7c2d12"} strokeWidth="1" strokeDasharray="2 2" />
                    
                    {/* Clothes / Water */}
                    {isRunning && isWasher && (
                         <path d="M 20 85 Q 50 100 80 85 T 140 85 V 120 H 20 Z" fill="#3b82f6" fillOpacity="0.5" className="animate-wave" />
                    )}
                    {isRunning && !isWasher && (
                         <>
                            <rect x="40" y="65" width="10" height="10" fill="#fca5a5" transform="rotate(20 45 70)" />
                            <rect x="55" y="80" width="8" height="12" fill="#93c5fd" transform="rotate(-40 59 86)" />
                         </>
                    )}
                </g>
                
                {/* Glass Reflection */}
                <path d="M 35 45 Q 50 60 65 45" fill="none" stroke="white" strokeWidth="2" strokeOpacity="0.3" />
                <circle cx="50" cy="75" r="28" fill={windowColor} fillOpacity="0.2" />
                <circle cx="65" cy="60" r="5" fill="white" fillOpacity="0.4" />
            </g>
            
            {/* Status LED */}
            <circle cx="80" cy="25" r="2" fill={isRunning ? "#22c55e" : isBroken ? "#ef4444" : "#64748b"} filter="url(#glow)" />
        </svg>
    )
}

const UpgradeCard = ({ label, level, cost, color, onClick, disabled }: any) => {
    const colors: any = {
        blue: "bg-blue-50 border-blue-200 text-blue-800",
        green: "bg-green-50 border-green-200 text-green-800",
        amber: "bg-amber-50 border-amber-200 text-amber-800",
    };
    
    return (
        <button 
            disabled={disabled}
            onClick={onClick}
            className={`p-2 border rounded-xl flex flex-col items-center justify-between h-20 transition-all ${colors[color]} ${disabled ? 'opacity-40 grayscale' : 'hover:scale-105 active:scale-95'}`}
        >
            <div className="text-[10px] uppercase font-bold tracking-wider">{label}</div>
            <div className="text-xl font-black">{level}</div>
            <div className="text-xs font-bold bg-white/50 px-2 rounded-full">${cost}</div>
        </button>
    )
}

const ShopButton = ({ type, dispatch, money }: { type: MachineType, dispatch: any, money: number }) => {
    const stats = MACHINE_STATS[type];
    const isWasher = (stats as any).type === 'washer';
    return (
        <button 
            onClick={() => dispatch({ type: 'BUY_MACHINE', machineType: type })}
            disabled={money < stats.cost}
            className={`
                group relative flex-shrink-0 w-28 h-32 p-3 
                border-2 rounded-xl flex flex-col items-center justify-between 
                transition-all duration-200 
                ${isWasher ? 'bg-white border-blue-100 hover:border-blue-400' : 'bg-white border-orange-100 hover:border-orange-400'} 
                disabled:opacity-50 disabled:hover:border-slate-200
            `}
        >
            <div className="text-3xl filter drop-shadow-sm group-hover:scale-110 transition-transform">
                {isWasher ? '🧼' : '💨'}
            </div>
            <div className="text-center w-full">
                <div className="font-bold text-[10px] text-slate-500 uppercase tracking-wide leading-none mb-1">{stats.name}</div>
                <div className={`font-black text-sm ${money >= stats.cost ? 'text-green-600' : 'text-red-400'}`}>${stats.cost}</div>
            </div>
            {/* Details Tooltip on hover could go here */}
        </button>
    )
}
