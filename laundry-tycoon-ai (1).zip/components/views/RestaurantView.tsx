
import React, { useState } from 'react';
import { useGame } from '../../context/GameContext';
import { TableType, TableState } from '../../types';
import { TABLE_STATS, CROP_STATS, ANIMAL_STATS, NEW_ITEMS } from '../../constants';
import { IsoCard } from '../ui/IsoCard';

export const RestaurantView: React.FC = () => {
  const { state, dispatch } = useGame();
  const [selectedTableId, setSelectedTableId] = useState<string | null>(null);

  const tables = state.restaurant.tables;

  const handleServe = (tableId: string, item: string) => {
      dispatch({ type: 'SERVE_TABLE', tableId, foodItem: item });
      setSelectedTableId(null);
  }

  const handleCollect = (e: React.MouseEvent, tableId: string) => {
      e.stopPropagation();
      dispatch({ type: 'COLLECT_TABLE', tableId });
  }

  // Helper to get available food from inventory
  const availableFood = (Object.entries(state.farm.inventory) as [string, number][]).filter(([key, val]) => {
      // Very basic check: if it has a sell price, it's edible for now (including Wheat for simplicity, or exclude crops)
      return val > 0 && key !== 'WHEAT'; 
  });

  return (
    <div className="flex flex-col h-full gap-4 pb-20">
      {/* Header Info */}
      <div className="bg-white/60 p-3 rounded-xl flex justify-between items-center backdrop-blur-md shadow-sm border border-white/50">
        <h2 className="text-xl font-black text-amber-900 tracking-tight flex items-center gap-2">
            <span>🍽️</span> РЕСТОРАН
        </h2>
        <span className="text-sm font-bold bg-amber-100 text-amber-700 px-3 py-1 rounded-full">Столов: {tables.length}</span>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-6 flex-1 overflow-y-auto content-start p-2 pb-24">
        {tables.map(table => {
            const stats = TABLE_STATS[table.type];
            const isEating = table.state === TableState.EATING;
            const isDirty = table.state === TableState.DIRTY;
            const isIdle = table.state === TableState.IDLE;
            
            return (
                <div key={table.id} className="relative">
                    <IsoCard 
                        depth="lg"
                        className={`
                            relative p-0 flex flex-col items-center overflow-visible transition-all duration-300
                            ${selectedTableId === table.id ? 'ring-4 ring-amber-400 z-20 scale-105 shadow-2xl' : 'hover:z-10 hover:scale-[1.02]'}
                        `}
                        onClick={() => isIdle && setSelectedTableId(selectedTableId === table.id ? null : table.id)}
                    >
                        <div className="w-full aspect-[4/3] p-2 relative">
                            <TableVisual table={table} />
                        </div>

                         {/* Status & Collect Overlay */}
                         <div className="absolute -bottom-3 w-[90%] bg-white/90 backdrop-blur border border-slate-200 shadow-lg rounded-lg p-2 flex flex-col gap-1 items-center z-10">
                             {isIdle && (
                                 <div className="text-[10px] font-black uppercase text-slate-400">Свободно</div>
                             )}
                             {isEating && (
                                 <div className="w-full">
                                     <div className="flex justify-between text-[10px] font-bold text-amber-800 mb-1">
                                         <span>Едят...</span>
                                         <span>{table.currentDish}</span>
                                     </div>
                                     <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                                        <div 
                                            className="bg-amber-500 h-full transition-all duration-1000 ease-linear" 
                                            style={{ width: `${(table.timer / stats.eatingTime) * 100}%` }}
                                        ></div>
                                    </div>
                                 </div>
                             )}
                             {isDirty && (
                                <button 
                                    onClick={(e) => handleCollect(e, table.id)}
                                    className="w-full bg-green-500 hover:bg-green-600 text-white text-[10px] font-bold py-1.5 rounded transition-colors shadow-sm animate-pulse flex items-center justify-center gap-1"
                                >
                                    <span>💰</span> ЗАБРАТЬ
                                </button>
                             )}
                         </div>

                         {/* Food Selection Menu (Popup when IDLE and Selected) */}
                         {selectedTableId === table.id && isIdle && (
                             <div className="absolute top-full mt-4 left-0 w-full bg-white rounded-xl shadow-2xl border border-slate-200 z-50 p-2 animate-in fade-in zoom-in-95">
                                 <div className="text-xs font-bold text-slate-700 mb-2 text-center uppercase">Выберите блюдо</div>
                                 <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto">
                                     {availableFood.length > 0 ? availableFood.map(([item, count]) => (
                                         <button 
                                            key={item}
                                            onClick={() => handleServe(table.id, item)}
                                            className="text-[10px] bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded p-1.5 text-left flex justify-between items-center"
                                         >
                                             <span className="font-bold text-amber-900 truncate max-w-[60%]">{item}</span>
                                             <span className="bg-white px-1.5 rounded text-slate-500">{count}</span>
                                         </button>
                                     )) : (
                                         <div className="col-span-2 text-center text-[10px] text-red-400 py-2">Нет еды на складе!</div>
                                     )}
                                 </div>
                             </div>
                         )}
                    </IsoCard>
                </div>
            );
        })}

        {/* Shop Section */}
        <div className="col-span-2 md:col-span-3 mt-8 pt-6 border-t border-slate-300/50">
            <h3 className="font-bold text-slate-700 text-sm mb-3 uppercase tracking-wide opacity-70">Магазин Мебели</h3>
            <div className="flex gap-3 overflow-x-auto pb-4 px-1 snap-x">
                <ShopButton type={TableType.BASIC} dispatch={dispatch} money={state.money} />
                <ShopButton type={TableType.LUXURY} dispatch={dispatch} money={state.money} />
            </div>
        </div>
      </div>
    </div>
  );
};

const ShopButton = ({ type, dispatch, money }: { type: TableType, dispatch: any, money: number }) => {
    const stats = TABLE_STATS[type];
    return (
        <button 
            onClick={() => dispatch({ type: 'BUY_TABLE', tableType: type })}
            disabled={money < stats.cost}
            className={`
                group relative flex-shrink-0 w-32 h-32 p-3 
                border-2 rounded-xl flex flex-col items-center justify-between 
                transition-all duration-200 bg-white border-amber-100 hover:border-amber-400 
                disabled:opacity-50 disabled:hover:border-slate-200
            `}
        >
            <div className="text-3xl filter drop-shadow-sm group-hover:scale-110 transition-transform">
                {type === TableType.BASIC ? '🪑' : '🛋️'}
            </div>
            <div className="text-center w-full">
                <div className="font-bold text-[10px] text-slate-500 uppercase tracking-wide leading-none mb-1">{stats.name}</div>
                <div className={`font-black text-sm ${money >= stats.cost ? 'text-green-600' : 'text-red-400'}`}>${stats.cost}</div>
            </div>
        </button>
    )
}

const TableVisual = ({ table }: { table: any }) => {
    const isLuxury = table.type === TableType.LUXURY;
    const isEating = table.state === TableState.EATING;
    const isDirty = table.state === TableState.DIRTY;
    
    return (
        <svg viewBox="0 0 100 80" className="w-full h-full drop-shadow-xl">
             {/* Floor Shadow */}
             <ellipse cx="50" cy="65" rx="35" ry="10" fill="black" opacity="0.1" />

             {/* Table Base/Legs */}
             {isLuxury ? (
                 <path d="M 30 60 L 30 40 L 70 40 L 70 60" fill="none" stroke="#78350f" strokeWidth="4" />
             ) : (
                 <path d="M 50 60 L 50 40" stroke="#475569" strokeWidth="4" />
             )}
             
             {/* Table Top (Isometric) */}
             <g transform="translate(0, 10)">
                 <path d="M 20 30 L 50 45 L 80 30 L 50 15 Z" fill={isLuxury ? "#7c2d12" : "#e2e8f0"} stroke={isLuxury ? "#451a03" : "#94a3b8"} strokeWidth="1" />
                 <path d="M 20 30 L 50 45 L 50 50 L 20 35 Z" fill={isLuxury ? "#501d0a" : "#cbd5e1"} /> {/* Thickness */}
                 <path d="M 80 30 L 50 45 L 50 50 L 80 35 Z" fill={isLuxury ? "#451a03" : "#94a3b8"} />
             </g>

             {/* Customer (Simplified) */}
             {isEating && (
                 <g className="animate-bounce-small">
                     {/* Chair Back (Behind) */}
                     <path d="M 30 25 L 30 10 Q 30 0 40 0 L 60 0 Q 70 0 70 10 L 70 25" fill="none" stroke="#94a3b8" strokeWidth="2" />
                     
                     {/* Head */}
                     <circle cx="50" cy="20" r="8" fill="#fca5a5" />
                     {/* Body */}
                     <path d="M 35 45 Q 50 25 65 45" fill="#3b82f6" />
                 </g>
             )}

             {/* Food on Table */}
             {isEating && (
                 <g transform="translate(50, 30)">
                     <ellipse cx="0" cy="0" rx="10" ry="5" fill="white" />
                     <circle cx="0" cy="-2" r="3" fill="#ef4444" />
                     <circle cx="4" cy="-1" r="2" fill="#22c55e" />
                 </g>
             )}

             {/* Dirty Plates / Money */}
             {isDirty && (
                 <g transform="translate(50, 30)">
                      <ellipse cx="-5" cy="2" rx="6" ry="3" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="0.5" />
                      <ellipse cx="5" cy="-2" rx="6" ry="3" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="0.5" />
                      
                      <g className="animate-bounce" transform="translate(0, -15)">
                          <text x="0" y="0" textAnchor="middle" fontSize="12">💵</text>
                      </g>
                 </g>
             )}
        </svg>
    )
}
