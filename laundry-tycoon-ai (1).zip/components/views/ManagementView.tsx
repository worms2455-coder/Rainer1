
import React from 'react';
import { useGame } from '../../context/GameContext';
import { DAILY_EXPENSES, PRICES, UPGRADE_COSTS, FURNITURE_ITEMS, RESOURCE_MARKET } from '../../constants';
import { IsoCard } from '../ui/IsoCard';

export const ManagementView: React.FC = () => {
  const { state, dispatch } = useGame();

  const handleHire = (role: 'technician' | 'receptionist' | 'admin' | 'farmer') => {
      dispatch({ type: 'HIRE_STAFF', role });
  };

  const handleRepairGen = (id: string) => dispatch({ type: 'REPAIR_GENERATOR', id });
  const handleUpgradeGen = (id: string) => dispatch({ type: 'UPGRADE_GENERATOR', id });
  const handleBuyFurniture = (itemId: string) => dispatch({ type: 'BUY_FURNITURE', itemId });
  const handleBuyResource = (type: 'WATER' | 'ENERGY') => dispatch({ type: 'BUY_RESOURCE', resource: type });

  return (
    <div className="flex flex-col h-full gap-4 pb-20 overflow-y-auto">
        <div className="bg-purple-50/50 p-3 rounded-lg backdrop-blur-sm border border-purple-200">
            <h2 className="text-xl font-bold text-purple-900">Офис и Инфраструктура</h2>
            <div className="flex flex-col gap-1 text-xs mt-2 text-purple-700">
                <span>Расходы в день: -${DAILY_EXPENSES.BASE} (База)</span>
                <span>Кредит: {state.stats.loanActive ? `Активен (${state.stats.loanDaysRemaining} дн)` : 'Нет'}</span>
            </div>
        </div>

        {/* Bank & Stats */}
        <div className="p-2">
            <h3 className="font-bold text-slate-700 mb-2">Финансы и Статистика</h3>
            <div className="grid grid-cols-2 gap-3">
                <IsoCard className="bg-white p-3" onClick={() => dispatch({ type: 'TAKE_LOAN' })} disabled={state.stats.loanActive}>
                    <div className="text-center">
                        <div className="font-bold text-slate-800">Взять Кредит</div>
                        <div className="text-green-600 font-bold text-lg">+$1000</div>
                        <div className="text-[10px] text-red-500 mt-1">Отдача $101/день (10 дн)</div>
                        {state.stats.loanActive && <div className="text-xs bg-red-100 text-red-800 rounded mt-1 font-bold">АКТИВЕН</div>}
                    </div>
                </IsoCard>
                <IsoCard className="bg-white p-3 cursor-default" depth="sm">
                     <div className="text-center">
                        <div className="font-bold text-slate-800">Статистика</div>
                        <div className="text-xs text-slate-500">Стирок: {state.stats.totalWashes}</div>
                        <div className="text-xs text-slate-500">Комфорт: {state.stats.comfort}</div>
                        <div className="text-xs text-slate-500">День: {state.day}</div>
                    </div>
                </IsoCard>
            </div>
        </div>

        {/* Resource Market */}
        <div className="p-2 bg-blue-50/50 rounded-xl mx-2 border border-blue-100">
             <h3 className="font-bold text-slate-700 mb-2">Рынок Ресурсов</h3>
             <div className="grid grid-cols-2 gap-3">
                 <button 
                    disabled={state.money < RESOURCE_MARKET.WATER_PACK.cost || state.resources.water >= state.resources.maxWater}
                    onClick={() => handleBuyResource('WATER')}
                    className="bg-white border border-blue-200 p-2 rounded-lg flex flex-col items-center shadow-sm active:scale-95 disabled:opacity-50"
                 >
                     <span className="text-2xl">💧</span>
                     <span className="text-xs font-bold text-slate-700">Вода (+50)</span>
                     <span className="text-xs text-green-600 font-bold">${RESOURCE_MARKET.WATER_PACK.cost}</span>
                 </button>
                 <button 
                    disabled={state.money < RESOURCE_MARKET.ENERGY_PACK.cost || state.resources.energy >= state.resources.maxEnergy}
                    onClick={() => handleBuyResource('ENERGY')}
                    className="bg-white border border-amber-200 p-2 rounded-lg flex flex-col items-center shadow-sm active:scale-95 disabled:opacity-50"
                 >
                     <span className="text-2xl">⚡</span>
                     <span className="text-xs font-bold text-slate-700">Энергия (+50)</span>
                     <span className="text-xs text-green-600 font-bold">${RESOURCE_MARKET.ENERGY_PACK.cost}</span>
                 </button>
             </div>
        </div>

        {/* Generators Section */}
        <div className="p-2 bg-slate-50 rounded-xl mx-2 border border-slate-200">
            <h3 className="font-bold text-slate-700 mb-2">Генераторы (Улучшение +50 Макс.)</h3>
            <div className="space-y-3">
                {state.generators.map(gen => {
                    const upgradeCost = UPGRADE_COSTS.GENERATOR_BASE * gen.level;
                    const isWater = gen.type === 'WATER';
                    const maxCap = isWater ? state.resources.maxWater : state.resources.maxEnergy;

                    return (
                        <IsoCard key={gen.id} className="p-3 bg-white" depth="sm">
                            <div className="flex justify-between items-start mb-2">
                                <div>
                                    <div className="font-bold text-slate-800">{isWater ? '💧 Водосборник' : '☀️ Солнечная Панель'}</div>
                                    <div className="text-xs text-slate-500">Ур. {gen.level} • Эфф: {Math.floor(gen.health)}%</div>
                                    <div className="text-[10px] text-blue-600 font-bold mt-1">Вместимость: {maxCap}</div>
                                </div>
                                <div className={`px-2 py-0.5 rounded text-[10px] font-bold ${gen.health < 50 ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                                    {gen.health < 100 ? 'НУЖЕН РЕМОНТ' : 'ОК'}
                                </div>
                            </div>
                            
                            {/* Health Bar */}
                            <div className="w-full bg-gray-200 h-1.5 rounded-full mb-3">
                                <div className="bg-blue-500 h-1.5 rounded-full" style={{ width: `${gen.health}%` }}></div>
                            </div>

                            <div className="flex gap-2">
                                <button 
                                    disabled={gen.health >= 100 || state.money < PRICES.REPAIR_GENERATOR}
                                    onClick={() => handleRepairGen(gen.id)}
                                    className="flex-1 bg-yellow-500 text-white text-xs py-1 rounded disabled:opacity-50 hover:bg-yellow-600 transition-colors"
                                >
                                    Чинить ${PRICES.REPAIR_GENERATOR}
                                </button>
                                <button 
                                    disabled={state.money < upgradeCost}
                                    onClick={() => handleUpgradeGen(gen.id)}
                                    className="flex-1 bg-blue-500 text-white text-xs py-1 rounded disabled:opacity-50 hover:bg-blue-600 transition-colors"
                                >
                                    Улучшить ${upgradeCost}
                                </button>
                            </div>
                        </IsoCard>
                    );
                })}
            </div>
        </div>

        {/* Staff Section */}
        <div className="p-2">
            <h3 className="font-bold text-slate-700 mb-2">Персонал ($1000 Найм + $100/день)</h3>
            <div className="space-y-3">
                <StaffCard 
                    title="Администратор" 
                    desc="Авто-сбор денег с готовых машин." 
                    active={state.staff.admin} 
                    onHire={() => handleHire('admin')}
                    money={state.money}
                />
                <StaffCard 
                    title="Фермер" 
                    desc="Авто-полив растений и кормление животных." 
                    active={state.staff.farmer} 
                    onHire={() => handleHire('farmer')}
                    money={state.money}
                />
                 <StaffCard 
                    title="Техник" 
                    desc="Снижает шанс поломки и стоимость ремонта." 
                    active={state.staff.technician} 
                    onHire={() => handleHire('technician')}
                    money={state.money}
                />
            </div>
        </div>

        {/* Furniture / Design Store */}
        <div className="p-2 mb-4">
            <h3 className="font-bold text-slate-700 mb-2">Магазин Дизайна (+Комфорт)</h3>
            <div className="grid grid-cols-2 gap-2">
                {FURNITURE_ITEMS.map(item => (
                    <IsoCard key={item.id} className="p-2 bg-white" depth="sm" onClick={() => handleBuyFurniture(item.id)} disabled={state.money < item.cost}>
                        <div className="text-sm font-bold">{item.name}</div>
                        <div className="text-xs text-green-600">${item.cost}</div>
                        <div className="text-[10px] text-purple-500">+{item.comfort} Комфорт</div>
                    </IsoCard>
                ))}
            </div>
        </div>
    </div>
  );
};

const StaffCard = ({ title, desc, active, onHire, money }: any) => (
    <IsoCard className={`p-3 flex justify-between items-center ${active ? 'bg-green-50 border-green-200' : 'bg-white'}`} depth="sm" disabled={active}>
        <div className="flex-1">
            <div className="font-bold text-slate-800 flex items-center gap-2">
                {title}
                {active && <span className="text-[10px] bg-green-200 text-green-800 px-1 rounded">НАНЯТ</span>}
            </div>
            <div className="text-xs text-slate-500 leading-tight pr-2">{desc}</div>
        </div>
        {!active && (
            <button 
                disabled={money < 1000}
                onClick={onHire}
                className="bg-purple-600 text-white text-xs px-3 py-2 rounded-lg font-bold disabled:opacity-50 hover:bg-purple-700 transition-colors"
            >
                НАНЯТЬ
            </button>
        )}
    </IsoCard>
);
