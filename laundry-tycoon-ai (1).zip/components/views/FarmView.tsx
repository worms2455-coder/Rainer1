
import React from 'react';
import { useGame } from '../../context/GameContext';
import { CropType, FarmPlot, AnimalType } from '../../types';
import { CROP_STATS, ANIMAL_STATS, BUILDING_COSTS, PLOT_UNLOCK_COSTS, NEW_ITEMS, INCUBATOR_TIMER } from '../../constants';
import { IsoCard } from '../ui/IsoCard';

export const FarmView: React.FC = () => {
  const { state, dispatch } = useGame();

  const handlePlant = (plotId: string, crop: CropType) => {
    dispatch({ type: 'PLANT_CROP', plotId, cropType: crop });
  };

  const handleAction = (plot: FarmPlot) => {
      if (plot.crop && plot.progress >= 100) {
          dispatch({ type: 'HARVEST_PLOT', plotId: plot.id });
      } else if (plot.crop && !plot.isWatered) {
          dispatch({ type: 'WATER_PLOT', plotId: plot.id });
      }
  };

  const handleUnlock = (plotId: string) => {
      dispatch({ type: 'UNLOCK_PLOT', plotId });
  }
  
  const sellItem = (item: string) => {
      dispatch({ type: 'SELL_ITEM', itemName: item, amount: 1 });
  }

  const handleBuildPen = (type: AnimalType) => dispatch({ type: 'BUILD_PEN', animalType: type });
  const handleBuyAnimal = (penId: string) => dispatch({ type: 'BUY_ANIMAL', penId });
  const handleFeed = (penId: string) => dispatch({ type: 'FEED_ANIMALS', penId });
  const handleCollectProduce = (penId: string) => dispatch({ type: 'COLLECT_ANIMAL_PRODUCE', penId });
  const handlePlaceChick = (penId: string) => dispatch({ type: 'PLACE_CHICK', penId });

  // Incubator Logic
  const eggCount = state.farm.inventory['ЯЙЦО'] || 0;
  const isIncubating = state.farm.incubator.isActive;
  const isReady = state.farm.incubator.ready;
  const batchSize = state.farm.incubator.batchSize || 1;

  const startIncubation = (size: number) => {
      dispatch({ type: 'START_INCUBATOR', batchSize: size });
  }

  return (
    <div className="flex flex-col h-full gap-4 pb-20">
      {/* Inventory Bar */}
      <div className="bg-white/80 p-3 rounded-xl backdrop-blur-md shadow-sm border border-green-100 shrink-0 flex flex-col gap-2">
        <div className="flex justify-between items-center">
            <h2 className="text-xl font-black text-green-900 tracking-tight flex items-center gap-2">
                <span>🌱</span> ЭКО-ФЕРМА
            </h2>
            <div className="text-[10px] font-bold uppercase text-green-600 bg-green-100 px-2 py-1 rounded">
                Склад: {Object.values(state.farm.inventory).reduce((a: number, b: number) => a + b, 0)}/{state.farm.inventoryLimit}
            </div>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {Object.entries(state.farm.inventory).map(([key, val]) => (
                <button 
                    key={key} 
                    onClick={() => sellItem(key)}
                    className="flex-shrink-0 bg-white px-3 py-1 rounded-lg shadow-sm border border-slate-200 flex items-center gap-2 hover:bg-red-50 hover:border-red-200 transition-colors group"
                >
                    <span className="font-bold text-slate-700 text-xs">{key}</span>
                    <span className="bg-slate-100 text-slate-600 px-1.5 rounded text-[10px] font-mono group-hover:bg-red-100 group-hover:text-red-600">{val}</span>
                </button>
            ))}
            {Object.keys(state.farm.inventory).length === 0 && <span className="text-xs text-slate-400 italic">Склад пуст...</span>}
        </div>
      </div>

      <div className="overflow-y-auto flex-1 p-2 space-y-8 pb-24">
        {/* Incubator Section */}
        <div className="bg-amber-50/50 p-4 rounded-2xl border border-amber-200 relative overflow-hidden">
            <h3 className="font-bold text-amber-800 mb-2 uppercase text-xs tracking-wider opacity-70">Инкубатор (Розыгрыш)</h3>
            <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center text-3xl shadow-inner border border-amber-100 relative">
                    {isIncubating ? (
                        <span className="animate-bounce">🥚</span>
                    ) : (
                        <span>🧺</span>
                    )}
                    {isIncubating && (
                         <div className="absolute -bottom-1 -right-1 bg-amber-500 text-white text-[10px] font-bold px-1.5 rounded-full border border-white">
                             x{batchSize}
                         </div>
                    )}
                </div>
                <div className="flex-1">
                    {!isIncubating ? (
                        <div className="flex flex-col gap-2">
                            <div className="text-xs text-amber-900 font-bold mb-1">Выберите партию:</div>
                            <div className="flex gap-2">
                                <button 
                                    disabled={eggCount < 1}
                                    onClick={() => startIncubation(1)}
                                    className="flex-1 bg-white border border-amber-200 text-amber-800 text-[10px] font-bold py-1 rounded hover:bg-amber-100 disabled:opacity-50"
                                >
                                    1x (Норм)
                                </button>
                                <button 
                                    disabled={eggCount < 5}
                                    onClick={() => startIncubation(5)}
                                    className="flex-1 bg-white border border-amber-200 text-amber-800 text-[10px] font-bold py-1 rounded hover:bg-amber-100 disabled:opacity-50 relative group"
                                >
                                    5x (Сложно)
                                    <span className="absolute -top-6 left-0 w-max bg-black/80 text-white text-[9px] p-1 rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity">Меньше еды/монет</span>
                                </button>
                                <button 
                                    disabled={eggCount < 10}
                                    onClick={() => startIncubation(10)}
                                    className="flex-1 bg-amber-100 border border-amber-300 text-amber-900 text-[10px] font-bold py-1 rounded hover:bg-amber-200 disabled:opacity-50 relative group"
                                >
                                    10x (Удача!)
                                    <span className="absolute -top-6 right-0 w-max bg-black/80 text-white text-[9px] p-1 rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity">Высокий шанс!</span>
                                </button>
                            </div>
                        </div>
                    ) : isReady ? (
                        <div className="text-green-600 font-bold animate-pulse">Готово к открытию!</div>
                    ) : (
                        <div>
                            <div className="text-xs font-bold text-amber-600">Ожидание...</div>
                            <div className="w-full h-2 bg-amber-200 rounded-full mt-1">
                                <div className="bg-amber-500 h-full rounded-full transition-all duration-1000 ease-linear" style={{ width: `${(state.farm.incubator.timer / INCUBATOR_TIMER) * 100}%` }}></div>
                            </div>
                        </div>
                    )}
                </div>
                <div className="shrink-0 flex items-center">
                    {isReady && (
                        <button 
                            onClick={() => dispatch({ type: 'OPEN_INCUBATOR' })}
                            className="bg-green-500 hover:bg-green-600 text-white font-bold text-xs px-4 py-2 rounded-lg shadow-md animate-bounce"
                        >
                            ОТКРЫТЬ!
                        </button>
                    )}
                </div>
            </div>
            {/* Reward Pop-up Text */}
            {state.farm.incubator.reward && (
                <div className="absolute top-0 right-0 bg-green-100 text-green-800 text-xs font-bold px-3 py-1 rounded-bl-xl animate-in fade-in slide-in-from-top-2 shadow-md max-w-[70%] text-right z-10">
                    {state.farm.incubator.reward}
                </div>
            )}
        </div>

        {/* Crops Section */}
        <div>
            <h3 className="font-bold text-slate-700 mb-3 uppercase text-xs tracking-wider opacity-70 px-1">Поля и Сады</h3>
            <div className="grid grid-cols-2 gap-6">
                {state.farm.plots.map((plot, idx) => {
                    const cropStats = plot.crop ? CROP_STATS[plot.crop] : null;
                    const isHarvestReady = plot.progress >= 100;
                    const unlockCost = idx === 2 ? PLOT_UNLOCK_COSTS.plot_3 : PLOT_UNLOCK_COSTS.plot_4;
                    
                    if (plot.isLocked) {
                        return (
                            <div key={plot.id} className="aspect-square bg-slate-100/50 rounded-xl border-2 border-dashed border-slate-300 flex flex-col items-center justify-center p-4 relative group hover:bg-slate-100 transition-colors">
                                <div className="text-4xl opacity-30 mb-2">🔒</div>
                                <div className="text-xs text-slate-400 font-bold mb-2 text-center">Участок закрыт</div>
                                <button 
                                    onClick={() => handleUnlock(plot.id)}
                                    disabled={state.money < unlockCost}
                                    className="bg-green-500 text-white text-xs font-bold px-3 py-1.5 rounded shadow hover:bg-green-600 disabled:bg-slate-400 disabled:cursor-not-allowed"
                                >
                                    Купить ${unlockCost}
                                </button>
                            </div>
                        )
                    }

                    return (
                        <div key={plot.id} className="relative group">
                             {/* Floating UI for Plot */}
                            <div className="absolute -top-4 left-0 right-0 z-20 flex justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                <div className="bg-black/70 text-white text-[10px] px-2 py-1 rounded backdrop-blur-sm">
                                    {plot.crop ? `${cropStats?.name} (${Math.floor(plot.progress)}%)` : "Пустая земля"}
                                </div>
                            </div>

                            {/* The Plot Visual */}
                            <div className="aspect-square relative transform hover:scale-105 transition-transform duration-300">
                                <FarmPlotVisual plot={plot} />
                                
                                {/* Overlay Controls - ALWAYS SHOW PLANT MENU IF NO HARVEST READY TO ALLOW REPLANT */}
                                <div className="absolute inset-0 flex flex-col items-center justify-center p-4 opacity-0 group-hover:opacity-100 transition-opacity bg-black/10 rounded-xl">
                                    {/* Always show plant menu if plot is not ready to harvest, allowing overwrite */}
                                    {!isHarvestReady ? (
                                        <div className="grid grid-cols-2 gap-1 w-full h-full content-center overflow-y-auto no-scrollbar">
                                             <PlantBtn label="Пшен" price={CROP_STATS.WHEAT.cost} color="yellow" onClick={() => handlePlant(plot.id, CropType.WHEAT)} />
                                             <PlantBtn label="Томат" price={CROP_STATS.TOMATO.cost} color="red" onClick={() => handlePlant(plot.id, CropType.TOMATO)} />
                                             <PlantBtn label="Огур" price={CROP_STATS.CUCUMBER.cost} color="green" onClick={() => handlePlant(plot.id, CropType.CUCUMBER)} />
                                             <PlantBtn label="Карт" price={CROP_STATS.POTATO.cost} color="amber" onClick={() => handlePlant(plot.id, CropType.POTATO)} />
                                             <PlantBtn label="Кукур" price={CROP_STATS.CORN.cost} color="yellow" onClick={() => handlePlant(plot.id, CropType.CORN)} />
                                             <PlantBtn label="Клуб" price={CROP_STATS.STRAWBERRY.cost} color="red" onClick={() => handlePlant(plot.id, CropType.STRAWBERRY)} />
                                             <PlantBtn label="Ябло" price={CROP_STATS.APPLE_TREE.cost} color="emerald" onClick={() => handlePlant(plot.id, CropType.APPLE_TREE)} />
                                             <PlantBtn label="Манго" price={CROP_STATS.MANGO_TREE.cost} color="orange" onClick={() => handlePlant(plot.id, CropType.MANGO_TREE)} />
                                             
                                             {/* Visual hint that planting replaces current */}
                                             {plot.crop && (
                                                 <div className="col-span-2 text-[8px] bg-red-500 text-white text-center font-bold rounded mt-1">
                                                     Посадка заменит текущее!
                                                 </div>
                                             )}
                                        </div>
                                    ) : (
                                        <div className="absolute bottom-2 w-[90%]">
                                            <button 
                                                onClick={() => handleAction(plot)}
                                                className={`
                                                    w-full py-2 rounded-lg font-bold text-xs shadow-lg backdrop-blur-sm border transition-all
                                                    bg-amber-500/90 hover:bg-amber-500 text-white border-amber-400 animate-bounce-small
                                                `}
                                            >
                                                СОБРАТЬ!
                                            </button>
                                        </div>
                                    )}
                                    
                                    {/* Water Button specific logic for already planted but not watered */}
                                    {plot.crop && !plot.isWatered && !isHarvestReady && (
                                         <button 
                                            onClick={(e) => { e.stopPropagation(); dispatch({ type: 'WATER_PLOT', plotId: plot.id })}}
                                            className="absolute bottom-2 left-2 right-2 bg-blue-500 text-white text-[10px] py-1 rounded font-bold shadow-md z-30"
                                         >
                                             ПОЛИТЬ
                                         </button>
                                    )}
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>

        {/* Animals Section */}
        <div>
            <h3 className="font-bold text-slate-700 mb-3 uppercase text-xs tracking-wider opacity-70 px-1">Животноводство</h3>
            
            {/* Building Construction Area */}
            {state.farm.pens.length < 2 && (
                <div className="flex gap-3 mb-6">
                    <button 
                        onClick={() => handleBuildPen(AnimalType.CHICKEN)}
                        disabled={state.money < BUILDING_COSTS.COOP}
                        className="flex-1 aspect-[2/1] border-2 border-dashed border-amber-300 rounded-xl bg-amber-50/50 hover:bg-amber-100 flex flex-col items-center justify-center gap-1 transition-colors group"
                    >
                        <span className="text-2xl group-hover:scale-125 transition-transform">🐔</span>
                        <div className="font-bold text-amber-800 text-xs">Курятник</div>
                        <div className="text-[10px] bg-amber-200 text-amber-900 px-2 rounded-full">${BUILDING_COSTS.COOP}</div>
                    </button>
                    <button 
                        onClick={() => handleBuildPen(AnimalType.COW)}
                        disabled={state.money < BUILDING_COSTS.BARN}
                        className="flex-1 aspect-[2/1] border-2 border-dashed border-slate-300 rounded-xl bg-slate-50/50 hover:bg-slate-100 flex flex-col items-center justify-center gap-1 transition-colors group"
                    >
                        <span className="text-2xl group-hover:scale-125 transition-transform">🐮</span>
                        <div className="font-bold text-slate-800 text-xs">Коровник</div>
                        <div className="text-[10px] bg-slate-200 text-slate-900 px-2 rounded-full">${BUILDING_COSTS.BARN}</div>
                    </button>
                </div>
            )}

            <div className="flex flex-col gap-4">
                {state.farm.pens.map(pen => {
                    const stats = ANIMAL_STATS[pen.type];
                    const hasChickItem = (state.farm.inventory[NEW_ITEMS.CHICK.name.toUpperCase()] || 0) > 0;
                    return (
                        <IsoCard key={pen.id} className="p-0 overflow-hidden bg-white" depth="md">
                            <div className="h-24 bg-gradient-to-b from-sky-200 to-sky-100 relative">
                                {/* Scenic Background */}
                                <div className="absolute bottom-0 w-full h-8 bg-[#86c268]"></div>
                                <div className="absolute bottom-4 left-4 text-4xl transform -scale-x-100">
                                    {pen.type === AnimalType.CHICKEN ? '🛖' : '🏠'}
                                </div>
                                
                                {/* Animals Visualization - Cap visual limit to 5 for UI clarity, but logic handles 10 */}
                                <div className="absolute bottom-2 right-4 flex gap-1 flex-wrap justify-end max-w-[150px]">
                                    {Array.from({ length: Math.min(6, pen.count) }).map((_, i) => (
                                        <div key={i} className="text-2xl animate-bounce-small" style={{ animationDelay: `${i * 0.2}s` }}>
                                            {pen.type === AnimalType.CHICKEN ? '🐔' : '🐮'}
                                        </div>
                                    ))}
                                    {pen.count > 6 && <span className="text-xs font-bold self-end">+{pen.count - 6}</span>}
                                </div>
                                
                                <div className="absolute top-2 left-3 bg-white/80 backdrop-blur px-2 py-1 rounded text-xs font-bold text-slate-700">
                                    {pen.type === AnimalType.CHICKEN ? 'Курятник' : 'Коровник'} ({pen.count}/{stats.maxPerPen})
                                </div>
                            </div>
                            
                            <div className="p-3">
                                <div className="flex justify-between items-center mb-3">
                                    <div className="flex flex-col w-2/3">
                                        <div className="flex justify-between text-[10px] text-slate-500 font-bold uppercase mb-1">
                                            <span>Сытость</span>
                                            <span>{Math.floor(pen.feedLevel)}%</span>
                                        </div>
                                        <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                                            <div className={`h-full ${pen.feedLevel < 20 ? 'bg-red-400' : 'bg-green-500'}`} style={{ width: `${pen.feedLevel}%` }}></div>
                                        </div>
                                    </div>
                                    
                                    {/* Buying / Placing Logic */}
                                    <div className="flex flex-col gap-1 items-end">
                                        {pen.count < stats.maxPerPen && (
                                            <button 
                                                onClick={() => handleBuyAnimal(pen.id)}
                                                className="text-[10px] bg-green-100 text-green-700 px-2 py-1 rounded-full font-bold border border-green-200 hover:bg-green-200"
                                            >
                                                +${stats.cost}
                                            </button>
                                        )}
                                        {pen.count < stats.maxPerPen && pen.type === AnimalType.CHICKEN && hasChickItem && (
                                            <button 
                                                onClick={() => handlePlaceChick(pen.id)}
                                                className="text-[10px] bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full font-bold border border-yellow-200 hover:bg-yellow-200 flex items-center gap-1"
                                            >
                                                <span>🐥</span> В курятник
                                            </button>
                                        )}
                                    </div>
                                </div>
                                
                                <div className="flex gap-2">
                                    <button 
                                        onClick={() => handleFeed(pen.id)}
                                        disabled={(state.farm.inventory['WHEAT'] || 0) < 1 || pen.feedLevel >= 100}
                                        className="flex-1 py-2 bg-amber-100 text-amber-800 rounded-lg text-xs font-bold hover:bg-amber-200 disabled:opacity-50 transition-colors"
                                    >
                                        Кормить 🌾
                                    </button>
                                    <button 
                                        onClick={() => handleCollectProduce(pen.id)}
                                        disabled={pen.produceReady < 1}
                                        className="flex-1 py-2 bg-blue-500 text-white rounded-lg text-xs font-bold shadow hover:bg-blue-600 disabled:opacity-50 disabled:bg-slate-300 transition-colors"
                                    >
                                        Собрать {Math.floor(pen.produceReady)}
                                    </button>
                                </div>
                            </div>
                        </IsoCard>
                    );
                })}
            </div>
        </div>
      </div>
    </div>
  );
};

const PlantBtn = ({ label, price, color, onClick }: any) => {
    const colors: any = {
        red: "bg-red-100 hover:bg-red-200 text-red-800 border-red-200",
        green: "bg-green-100 hover:bg-green-200 text-green-800 border-green-200",
        yellow: "bg-yellow-100 hover:bg-yellow-200 text-yellow-800 border-yellow-200",
        emerald: "bg-emerald-100 hover:bg-emerald-200 text-emerald-800 border-emerald-200",
        amber: "bg-amber-100 hover:bg-amber-200 text-amber-800 border-amber-200",
        orange: "bg-orange-100 hover:bg-orange-200 text-orange-800 border-orange-200",
    }
    return (
        <button onClick={onClick} className={`p-1 rounded border text-[10px] font-bold transition-all hover:scale-105 shadow-sm flex flex-col items-center justify-center h-12 ${colors[color]}`}>
            <span>{label}</span>
            <span className="opacity-70">${price}</span>
        </button>
    )
}

const FarmPlotVisual = ({ plot }: { plot: FarmPlot }) => {
    const isWatered = plot.isWatered;
    const cropStats = plot.crop ? CROP_STATS[plot.crop] : null;
    const progress = plot.progress / 100;
    
    // Scale plant based on progress
    const scale = 0.2 + (progress * 0.8);
    
    return (
        <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-xl">
             <defs>
                 <linearGradient id="soilGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                     <stop offset="0%" stopColor="#8d6e63" />
                     <stop offset="100%" stopColor="#5d4037" />
                 </linearGradient>
                 <linearGradient id="wateredSoil" x1="0%" y1="0%" x2="0%" y2="100%">
                     <stop offset="0%" stopColor="#6d4c41" />
                     <stop offset="100%" stopColor="#3e2723" />
                 </linearGradient>
             </defs>
             
             {/* Base Soil Block (Isometric) */}
             <path d="M 50 10 L 90 35 L 50 60 L 10 35 Z" fill={isWatered ? "url(#wateredSoil)" : "url(#soilGradient)"} stroke="#3e2723" strokeWidth="1" />
             <path d="M 10 35 L 50 60 L 50 90 L 10 65 Z" fill="#4e342e" /> {/* Left Face */}
             <path d="M 90 35 L 50 60 L 50 90 L 90 65 Z" fill="#3e2723" /> {/* Right Face */}
             
             {/* Plant Growth */}
             {plot.crop && (
                 <g transform={`translate(50, 45) scale(${scale})`}>
                     {/* Shadow */}
                     <ellipse cx="0" cy="10" rx="15" ry="5" fill="black" opacity="0.2" />
                     
                     {/* Different Visuals per Crop */}
                     {plot.crop === CropType.TOMATO && (
                         <g className="animate-sway">
                             <path d="M 0 10 Q -5 -10 -15 -20 M 0 10 Q 5 -15 15 -25 M 0 10 V -30" stroke="#4ade80" strokeWidth="3" fill="none" />
                             {progress > 0.5 && <circle cx="-15" cy="-20" r="5" fill="#ef4444" />}
                             {progress > 0.7 && <circle cx="15" cy="-25" r="6" fill="#ef4444" />}
                             <path d="M 0 -30 L -5 -40 L 0 -35 L 5 -40 Z" fill="#22c55e" />
                         </g>
                     )}
                     
                     {plot.crop === CropType.WHEAT && (
                         <g className="animate-sway">
                             <path d="M -5 10 Q -10 -20 -5 -40" stroke="#facc15" strokeWidth="2" fill="none" />
                             <path d="M 0 10 Q 0 -30 0 -50" stroke="#facc15" strokeWidth="2" fill="none" />
                             <path d="M 5 10 Q 10 -20 5 -40" stroke="#facc15" strokeWidth="2" fill="none" />
                             {progress > 0.6 && (
                                 <>
                                     <ellipse cx="-5" cy="-40" rx="2" ry="6" fill="#eab308" />
                                     <ellipse cx="0" cy="-50" rx="2" ry="6" fill="#eab308" />
                                     <ellipse cx="5" cy="-40" rx="2" ry="6" fill="#eab308" />
                                 </>
                             )}
                         </g>
                     )}
                     
                      {plot.crop === CropType.CUCUMBER && (
                         <g className="animate-sway">
                             <path d="M 0 10 C -20 10 -10 -20 -20 -30" stroke="#22c55e" strokeWidth="3" fill="none" />
                             <path d="M 0 10 C 20 10 10 -20 20 -30" stroke="#22c55e" strokeWidth="3" fill="none" />
                             {progress > 0.6 && <ellipse cx="-15" cy="-15" rx="3" ry="8" fill="#166534" transform="rotate(-20)" />}
                             {progress > 0.8 && <ellipse cx="15" cy="-15" rx="3" ry="8" fill="#166534" transform="rotate(20)" />}
                         </g>
                     )}

                     {plot.crop === CropType.POTATO && (
                         <g>
                             <circle cx="0" cy="5" r="15" fill="#5d4037" />
                             <circle cx="-5" cy="0" r="3" fill="#8d6e63" />
                             <path d="M 0 -5 L -10 -20 L 0 -15 L 10 -20 Z" fill="#4ade80" />
                             {progress > 0.8 && <circle cx="5" cy="5" r="4" fill="#d4a373" />}
                         </g>
                     )}

                     {plot.crop === CropType.STRAWBERRY && (
                         <g className="animate-sway">
                             <path d="M 0 0 Q -10 -5 -15 -10" stroke="#22c55e" strokeWidth="2" fill="none" />
                             <path d="M 0 0 Q 10 -5 15 -10" stroke="#22c55e" strokeWidth="2" fill="none" />
                             {progress > 0.6 && <path d="M -5 -10 L 0 0 L 5 -10 Q 0 -15 -5 -10 Z" fill="#ef4444" />}
                             {progress > 0.8 && <path d="M -10 5 L -5 15 L 0 5 Q -5 0 -10 5 Z" fill="#ef4444" />}
                         </g>
                     )}

                     {plot.crop === CropType.CORN && (
                         <g>
                             <rect x="-2" y="-40" width="4" height="50" fill="#facc15" />
                             <ellipse cx="0" cy="-20" rx="6" ry="15" fill="#facc15" />
                             <path d="M -2 10 Q -10 -10 -2 50" stroke="#22c55e" strokeWidth="2" fill="none" />
                             <path d="M 2 10 Q 10 -10 2 50" stroke="#22c55e" strokeWidth="2" fill="none" />
                         </g>
                     )}

                     {(plot.crop === CropType.APPLE_TREE || plot.crop === CropType.MANGO_TREE) && (
                         <g>
                             {/* Trunk */}
                             <path d="M -5 10 L -5 -20 L 5 -20 L 5 10 Z" fill="#5d4037" />
                             
                             {/* Foliage */}
                             <circle cx="0" cy="-35" r="25" fill={plot.crop === CropType.APPLE_TREE ? "#16a34a" : "#15803d"} />
                             <circle cx="-15" cy="-25" r="15" fill={plot.crop === CropType.APPLE_TREE ? "#22c55e" : "#16a34a"} />
                             <circle cx="15" cy="-25" r="15" fill={plot.crop === CropType.APPLE_TREE ? "#22c55e" : "#16a34a"} />
                             
                             {/* Fruits */}
                             {progress > 0.8 && (
                                 <>
                                     <circle cx="-10" cy="-40" r="4" fill={plot.crop === CropType.APPLE_TREE ? "#ef4444" : "#fbbf24"} />
                                     <circle cx="10" cy="-30" r="4" fill={plot.crop === CropType.APPLE_TREE ? "#ef4444" : "#fbbf24"} />
                                     <circle cx="0" cy="-20" r="4" fill={plot.crop === CropType.APPLE_TREE ? "#ef4444" : "#fbbf24"} />
                                 </>
                             )}
                         </g>
                     )}
                 </g>
             )}
             
             {/* Water Droplet Hint */}
             {plot.crop && !plot.isWatered && (
                 <g className="animate-bounce-small">
                     <path d="M 50 15 Q 55 25 50 30 Q 45 25 50 15" fill="#3b82f6" opacity="0.8" />
                 </g>
             )}
        </svg>
    )
}
