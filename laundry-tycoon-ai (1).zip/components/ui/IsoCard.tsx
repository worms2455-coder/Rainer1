import React from 'react';

interface IsoCardProps {
  children: React.ReactNode;
  className?: string;
  depth?: 'sm' | 'md' | 'lg';
  active?: boolean;
  onClick?: () => void;
  disabled?: boolean;
}

export const IsoCard: React.FC<IsoCardProps> = ({ 
  children, 
  className = '', 
  depth = 'md', 
  active = false,
  onClick,
  disabled
}) => {
  const depthClass = {
    sm: 'border-b-2 border-r-2',
    md: 'border-b-4 border-r-4',
    lg: 'border-b-8 border-r-8'
  }[depth];

  const activeClass = active ? 'translate-y-1 translate-x-1 border-b-0 border-r-0 shadow-inner' : '';
  const disabledClass = disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:-translate-y-1 hover:-translate-x-1 active:translate-y-0 active:translate-x-0';

  return (
    <div 
      onClick={!disabled ? onClick : undefined}
      className={`
        bg-white/80 backdrop-blur-md border border-white/40 
        rounded-xl transition-all duration-200 shadow-xl
        ${depthClass} ${disabled ? '' : 'border-blue-900/20'}
        ${disabledClass}
        ${activeClass}
        ${className}
      `}
    >
      {children}
    </div>
  );
};