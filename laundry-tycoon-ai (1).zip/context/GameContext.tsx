
import React, { createContext, useContext, useEffect, useReducer } from 'react';
import { 
  GameState, Machine, MachineState, MachineType, Weather, 
  CropType, AnimalType, AnimalPen, Quest, TableType, TableState, RestaurantTable
} from '../types';
import { 
  TICK_RATE, DAY_LENGTH_SECONDS, MACHINE_STATS, CROP_STATS, 
  ANIMAL_STATS, DAILY_EXPENSES, UPGRADE_COSTS, PRICES, BUILDING_COSTS, FURNITURE_ITEMS,
  PLOT_UNLOCK_COSTS, QUESTS_DATA, INCUBATOR_TIMER, NEW_ITEMS, TABLE_STATS, RESOURCE_MARKET
} from '../constants';

const INITIAL_QUESTS: Quest[] = QUESTS_DATA.map(q => ({ ...q, progress: 0, isClaimed: false })) as any;

const INITIAL_STATE: GameState = {
  money: 1200,
  day: 1,
  time: 0,
  weather: Weather.SUNNY,
  resources: {
    water: 100,
    maxWater: 200,
    energy: 100,
    maxEnergy: 200,
  },
  machines: [],
  generators: [
    { id: 'gen_sol_1', type: 'SOLAR', level: 1, health: 100 },
    { id: 'gen_wat_1', type: 'WATER', level: 1, health: 100 }
  ],
  farm: {
    plots: [
        { id: 'plot_1', crop: null, progress: 0, soilQuality: 100, isWatered: false, isLocked: false },
        { id: 'plot_2', crop: null, progress: 0, soilQuality: 100, isWatered: false, isLocked: false },
        { id: 'plot_3', crop: null, progress: 0, soilQuality: 100, isWatered: false, isLocked: true },
        { id: 'plot_4', crop: null, progress: 0, soilQuality: 100, isWatered: false, isLocked: true },
    ],
    pens: [],
    inventory: { "WHEAT": 5, "ЯЙЦО": 20, "ПОМИДОР": 1 }, 
    inventoryLimit: 50,
    incubator: { isActive: false, startTime: 0, timer: 0, ready: false, batchSize: 0 }
  },
  restaurant: {
    tables: []
  },
  quests: INITIAL_QUESTS,
  staff: {
    technician: false,
    receptionist: false,
    admin: false,
    farmer: false,
    chef: false
  },
  stats: {
    totalWashes: 0,
    comfort: 10,
    loanActive: false,
    loanDaysRemaining: 0
  }
};

type Action = 
  | { type: 'TICK' }
  | { type: 'BUY_MACHINE'; machineType: MachineType }
  | { type: 'START_MACHINE'; id: string }
  | { type: 'COLLECT_MACHINE'; id: string }
  | { type: 'REPAIR_MACHINE'; id: string }
  | { type: 'UPGRADE_MACHINE'; id: string; upgradeType: 'SPEED' | 'ECO' | 'CAP' }
  | { type: 'UNLOCK_PLOT'; plotId: string }
  | { type: 'PLANT_CROP'; plotId: string; cropType: CropType }
  | { type: 'WATER_PLOT'; plotId: string }
  | { type: 'HARVEST_PLOT'; plotId: string }
  | { type: 'BUILD_PEN'; animalType: AnimalType }
  | { type: 'BUY_ANIMAL'; penId: string }
  | { type: 'FEED_ANIMALS'; penId: string }
  | { type: 'COLLECT_ANIMAL_PRODUCE'; penId: string }
  | { type: 'SELL_ITEM'; itemName: string; amount: number }
  | { type: 'START_INCUBATOR'; batchSize: number }
  | { type: 'OPEN_INCUBATOR' }
  | { type: 'PLACE_CHICK'; penId: string }
  | { type: 'CLAIM_QUEST'; questId: string }
  | { type: 'HIRE_STAFF'; role: keyof GameState['staff'] }
  | { type: 'TAKE_LOAN' }
  | { type: 'REPAIR_GENERATOR'; id: string }
  | { type: 'UPGRADE_GENERATOR'; id: string }
  | { type: 'BUY_FURNITURE'; itemId: string }
  | { type: 'BUY_TABLE'; tableType: TableType }
  | { type: 'SERVE_TABLE'; tableId: string; foodItem: string }
  | { type: 'COLLECT_TABLE'; tableId: string }
  | { type: 'BUY_RESOURCE'; resource: 'WATER' | 'ENERGY' };

const gameReducer = (state: GameState, action: Action): GameState => {
  switch (action.type) {
    case 'TICK': {
      let newState = { ...state };
      
      // 1. Time & Weather
      newState.time += 1;
      if (newState.time >= DAY_LENGTH_SECONDS) {
        newState.time = 0;
        newState.day += 1;
        
        // Expenses
        let dailyCost = DAILY_EXPENSES.BASE;
        if (newState.staff.technician) dailyCost += DAILY_EXPENSES.STAFF_SALARY;
        if (newState.staff.receptionist) dailyCost += DAILY_EXPENSES.STAFF_SALARY;
        if (newState.staff.admin) dailyCost += DAILY_EXPENSES.STAFF_SALARY;
        if (newState.staff.farmer) dailyCost += DAILY_EXPENSES.STAFF_SALARY;
        if (newState.staff.chef) dailyCost += DAILY_EXPENSES.STAFF_SALARY;
        
        if (newState.stats.loanActive) {
            dailyCost += DAILY_EXPENSES.LOAN_PAYMENT;
            newState.stats.loanDaysRemaining -= 1;
            if (newState.stats.loanDaysRemaining <= 0) {
                newState.stats.loanActive = false;
            }
        }
        newState.money -= dailyCost;
        
        // Weather Change
        const rand = Math.random();
        if (rand < 0.4) newState.weather = Weather.SUNNY;
        else if (rand < 0.7) newState.weather = Weather.CLOUDY;
        else newState.weather = Weather.RAINY;
      }

      // 2. Incubator Logic
      if (newState.farm.incubator.isActive && !newState.farm.incubator.ready) {
          if (newState.farm.incubator.timer > 0) {
              newState.farm.incubator.timer -= 1;
          } else {
              newState.farm.incubator.ready = true;
          }
      }

      // 3. Resource Generation
      let energyGen = 0.5;
      newState.generators.forEach(g => {
        if (g.type === 'SOLAR') {
             let eff = 1;
             if (newState.weather !== Weather.SUNNY) eff = 0.5;
             if (g.health < 50) eff *= 0.5;
             energyGen += (0.5 * g.level * eff);
        }
        if (Math.random() < 0.0005) g.health = Math.max(0, g.health - 10);
      });
      
      let waterGen = 0;
      if (newState.weather === Weather.RAINY) {
        newState.generators.filter(g => g.type === 'WATER').forEach(g => {
             let eff = 1;
             if (g.health < 50) eff *= 0.5;
             waterGen += (1.0 * g.level * eff);
        });
      }

      newState.resources.energy = Math.min(newState.resources.maxEnergy, newState.resources.energy + energyGen);
      newState.resources.water = Math.min(newState.resources.maxWater, newState.resources.water + waterGen);

      // 4. Machine Logic
      newState.machines = newState.machines.map(m => {
        if (m.state === MachineState.RUNNING) {
            const breakChance = newState.staff.technician ? 0.0001 : 0.0005;
            if (Math.random() < breakChance) return { ...m, state: MachineState.BROKEN };

            if (m.timer > 0) return { ...m, timer: m.timer - 1 };
            else return { ...m, state: MachineState.DONE };
        }
        return m;
      });

      // 4.5 Restaurant Logic
      if (newState.restaurant && newState.restaurant.tables) {
          newState.restaurant.tables = newState.restaurant.tables.map(t => {
              if (t.state === TableState.EATING) {
                  if (t.timer > 0) return { ...t, timer: t.timer - 1 };
                  else return { ...t, state: TableState.DIRTY };
              }
              return t;
          });
      }

      // Auto Collect (Admin)
      if (newState.staff.admin) {
        newState.machines.forEach((m, idx) => {
            if (m.state === MachineState.DONE) {
                const stats = MACHINE_STATS[m.type];
                let income = stats.income * (1 + (m.levelCap * 0.15));
                newState.stats.totalWashes += 1;
                
                newState.quests = newState.quests.map(q => 
                    q.type === 'WASH' && !q.isClaimed ? { ...q, progress: Math.min(q.target, q.progress + 1) } : q
                );

                if (newState.stats.totalWashes % 10 === 0) income += 50;
                newState.money += income;
                newState.machines[idx] = { ...m, state: MachineState.IDLE, timer: stats.cycleTime };
            }
        });
      }

      // 5. Farm Logic
      newState.farm.plots = newState.farm.plots.map(p => {
        if (!p.isLocked && p.crop && p.progress < 100) {
            let growth = 1; 
            if (!p.isWatered) growth = 0.1;
            growth *= (p.soilQuality / 100);
            
            if (newState.staff.farmer && !p.isWatered && newState.resources.water >= 5) {
                p.isWatered = true;
                newState.resources.water -= 5;
            }

            const totalTime = CROP_STATS[p.crop].growthTime;
            const percentStep = (100 / totalTime) * growth;
            return { ...p, progress: Math.min(100, p.progress + percentStep) };
        }
        return p;
      });

      // Animal Logic
      newState.farm.pens = newState.farm.pens.map(pen => {
          if (pen.count > 0 && pen.feedLevel > 0) {
             pen.feedLevel -= 0.02 * pen.count; 
             const produceRate = (100 / ANIMAL_STATS[pen.type].cycle);
             pen.produceReady += (produceRate * pen.count) / 100;
             if (pen.feedLevel < 0) pen.feedLevel = 0;
          } else if (newState.staff.farmer && pen.count > 0 && pen.feedLevel < 10) {
              if ((newState.farm.inventory['WHEAT'] || 0) >= 1) {
                   newState.farm.inventory['WHEAT'] -= 1;
                   pen.feedLevel += 50; 
              }
          }
          return pen;
      });

      return newState;
    }

    // --- RESTAURANT ACTIONS ---

    case 'BUY_TABLE': {
        const stats = TABLE_STATS[action.tableType];
        if (state.money >= stats.cost) {
            const newTable: RestaurantTable = {
                id: `tbl_${Date.now()}`,
                type: action.tableType,
                state: TableState.IDLE,
                timer: 0,
                currentDish: null,
                dishValue: 0
            };
            return {
                ...state,
                money: state.money - stats.cost,
                restaurant: {
                    ...state.restaurant,
                    tables: [...state.restaurant.tables, newTable]
                }
            }
        }
        return state;
    }

    case 'SERVE_TABLE': {
        const table = state.restaurant.tables.find(t => t.id === action.tableId);
        if (!table || table.state !== TableState.IDLE) return state;

        const inventory = { ...state.farm.inventory };
        if (!inventory[action.foodItem] || inventory[action.foodItem] < 1) return state;

        // Calculate Value
        let baseValue = 10;
        Object.values(CROP_STATS).forEach(s => { if(s.name.toUpperCase() === action.foodItem) baseValue = s.sellPrice });
        Object.values(ANIMAL_STATS).forEach(s => { if(s.produceName.toUpperCase() === action.foodItem) baseValue = s.producePrice });
        Object.values(NEW_ITEMS).forEach(s => { if(s.name.toUpperCase() === action.foodItem) baseValue = s.sellPrice });

        inventory[action.foodItem] -= 1;
        const stats = TABLE_STATS[table.type];

        return {
            ...state,
            farm: { ...state.farm, inventory },
            restaurant: {
                ...state.restaurant,
                tables: state.restaurant.tables.map(t => t.id === action.tableId ? { 
                    ...t, 
                    state: TableState.EATING, 
                    timer: stats.eatingTime, 
                    currentDish: action.foodItem,
                    dishValue: baseValue
                } : t)
            }
        };
    }

    case 'COLLECT_TABLE': {
        const table = state.restaurant.tables.find(t => t.id === action.tableId);
        if (!table || table.state !== TableState.DIRTY) return state;

        const stats = TABLE_STATS[table.type];
        // Income = Base Food Value * Table Multiplier + Comfort Bonus
        const income = Math.ceil(table.dishValue * stats.multiplier * (1 + state.stats.comfort/100));

        // Quest: Earn
        const updatedQuests = state.quests.map(q => 
            q.type === 'EARN' && !q.isClaimed ? { ...q, progress: Math.min(q.target, q.progress + income) } : q
        );

        return {
            ...state,
            money: state.money + income,
            quests: updatedQuests,
            restaurant: {
                ...state.restaurant,
                tables: state.restaurant.tables.map(t => t.id === action.tableId ? {
                    ...t,
                    state: TableState.IDLE,
                    timer: 0,
                    currentDish: null,
                    dishValue: 0
                } : t)
            }
        };
    }

    case 'BUY_MACHINE': {
      const cost = MACHINE_STATS[action.machineType].cost;
      if (state.money >= cost) {
        const newMachine: Machine = {
          id: `m_${Date.now()}`,
          type: action.machineType,
          state: MachineState.IDLE,
          timer: MACHINE_STATS[action.machineType].cycleTime,
          maxTime: MACHINE_STATS[action.machineType].cycleTime,
          levelSpeed: 0,
          levelEco: 0,
          levelCap: 0
        };
        return { ...state, money: state.money - cost, machines: [...state.machines, newMachine] };
      }
      return state;
    }

    case 'START_MACHINE': {
      const machine = state.machines.find(m => m.id === action.id);
      if (!machine || machine.state !== MachineState.IDLE) return state;
      
      const stats = MACHINE_STATS[machine.type];
      const waterCost = stats.water * (1 - (machine.levelEco * 0.1));
      const energyCost = stats.energy * (1 - (machine.levelEco * 0.1));

      if (state.resources.water >= waterCost && state.resources.energy >= energyCost) {
        const updatedMachines = state.machines.map(m => {
            if (m.id === action.id) return { ...m, state: MachineState.RUNNING };
            return m;
        });
        return {
            ...state,
            resources: {
                ...state.resources,
                water: state.resources.water - waterCost,
                energy: state.resources.energy - energyCost
            },
            machines: updatedMachines
        };
      }
      return state;
    }

    case 'COLLECT_MACHINE': {
      const machine = state.machines.find(m => m.id === action.id);
      if (!machine || machine.state !== MachineState.DONE) return state;

      const stats = MACHINE_STATS[machine.type];
      let income = stats.income * (1 + (machine.levelCap * 0.15));
      
      const newTotalWashes = state.stats.totalWashes + 1;
      if (newTotalWashes % 10 === 0) income += 50; 

      const newMaxTime = stats.cycleTime * (1 - (machine.levelSpeed * 0.1));

      // Update Quests
      const updatedQuests = state.quests.map(q => 
        q.type === 'WASH' && !q.isClaimed ? { ...q, progress: Math.min(q.target, q.progress + 1) } : q
      );

      // Earn Money Quest
      const updatedQuests2 = updatedQuests.map(q =>
        q.type === 'EARN' && !q.isClaimed ? { ...q, progress: Math.min(q.target, q.progress + income) } : q
      );

      const updatedMachines = state.machines.map(m => {
          if (m.id === action.id) return { ...m, state: MachineState.IDLE, timer: newMaxTime, maxTime: newMaxTime };
          return m;
      });

      return {
          ...state,
          money: state.money + income,
          stats: { ...state.stats, totalWashes: newTotalWashes },
          machines: updatedMachines,
          quests: updatedQuests2
      };
    }

    case 'UNLOCK_PLOT': {
        const cost = (PLOT_UNLOCK_COSTS as any)[action.plotId];
        if (state.money >= cost) {
            return {
                ...state,
                money: state.money - cost,
                farm: {
                    ...state.farm,
                    plots: state.farm.plots.map(p => p.id === action.plotId ? { ...p, isLocked: false } : p)
                }
            }
        }
        return state;
    }

    case 'REPAIR_MACHINE': {
       const cost = state.staff.technician ? 25 : 50;
       if (state.money >= cost) {
           return {
               ...state,
               money: state.money - cost,
               machines: state.machines.map(m => m.id === action.id ? { ...m, state: MachineState.IDLE } : m)
           }
       }
       return state;
    }

    case 'PLANT_CROP': {
        const plot = state.farm.plots.find(p => p.id === action.plotId);
        const stats = CROP_STATS[action.cropType];
        // ALLOW OVERWRITING: Removed check for !plot.crop
        if (!plot || plot.isLocked || state.money < stats.cost) return state;

        return {
            ...state,
            money: state.money - stats.cost,
            farm: {
                ...state.farm,
                plots: state.farm.plots.map(p => p.id === action.plotId ? { ...p, crop: action.cropType, progress: 0, isWatered: false } : p)
            }
        };
    }

    case 'WATER_PLOT': {
        if (state.resources.water < 5) return state;
        return {
            ...state,
            resources: { ...state.resources, water: state.resources.water - 5 },
            farm: {
                ...state.farm,
                plots: state.farm.plots.map(p => p.id === action.plotId ? { ...p, isWatered: true } : p)
            }
        };
    }

    case 'HARVEST_PLOT': {
        const plot = state.farm.plots.find(p => p.id === action.plotId);
        if (!plot || !plot.crop || plot.progress < 100) return state;
        
        const cropName = CROP_STATS[plot.crop].name.toUpperCase();
        const currentAmount = state.farm.inventory[cropName] || 0;
        
        const totalItems = Object.values(state.farm.inventory).reduce((a, b) => a + b, 0);
        if (totalItems >= state.farm.inventoryLimit) return state;

        const stats = CROP_STATS[plot.crop];
        let newPlot = { ...plot, progress: 0, isWatered: false, soilQuality: Math.max(0, plot.soilQuality - 10) };
        
        if (!stats.isTree) {
            newPlot.crop = null;
        } else {
             if (plot.harvestsRemaining && plot.harvestsRemaining <= 1) {
                 newPlot.crop = null;
             } else {
                 const maxHarvests = (stats as any).harvests || 5;
                 newPlot.harvestsRemaining = (plot.harvestsRemaining || maxHarvests) - 1;
             }
        }

        // Quest Progress: Harvest
        const updatedQuests = state.quests.map(q => 
            q.type === 'HARVEST' && !q.isClaimed ? { ...q, progress: Math.min(q.target, q.progress + 1) } : q
        );

        return {
            ...state,
            quests: updatedQuests,
            farm: {
                ...state.farm,
                inventory: { ...state.farm.inventory, [cropName]: currentAmount + 1 },
                plots: state.farm.plots.map(p => p.id === action.plotId ? newPlot : p)
            }
        };
    }

    case 'BUILD_PEN': {
        const cost = action.animalType === AnimalType.CHICKEN ? BUILDING_COSTS.COOP : BUILDING_COSTS.BARN;
        if (state.money >= cost) {
            const newPen: AnimalPen = {
                id: `pen_${Date.now()}`,
                type: action.animalType,
                count: 0,
                feedLevel: 0,
                produceReady: 0
            };
            return {
                ...state,
                money: state.money - cost,
                farm: { ...state.farm, pens: [...state.farm.pens, newPen] }
            };
        }
        return state;
    }

    case 'BUY_ANIMAL': {
        const pen = state.farm.pens.find(p => p.id === action.penId);
        if (!pen) return state;
        const stats = ANIMAL_STATS[pen.type];
        if (state.money >= stats.cost && pen.count < stats.maxPerPen) {
             return {
                 ...state,
                 money: state.money - stats.cost,
                 farm: {
                     ...state.farm,
                     pens: state.farm.pens.map(p => p.id === action.penId ? { ...p, count: p.count + 1 } : p)
                 }
             }
        }
        return state;
    }

    case 'PLACE_CHICK': {
        const pen = state.farm.pens.find(p => p.id === action.penId);
        const chicks = state.farm.inventory[NEW_ITEMS.CHICK.name.toUpperCase()] || 0;
        
        if (!pen || pen.type !== AnimalType.CHICKEN || chicks < 1) return state;
        const stats = ANIMAL_STATS[pen.type];

        if (pen.count < stats.maxPerPen) {
            return {
                ...state,
                farm: {
                    ...state.farm,
                    inventory: { ...state.farm.inventory, [NEW_ITEMS.CHICK.name.toUpperCase()]: chicks - 1 },
                    pens: state.farm.pens.map(p => p.id === action.penId ? { ...p, count: p.count + 1 } : p)
                }
            }
        }
        return state;
    }

    case 'FEED_ANIMALS': {
        const pen = state.farm.pens.find(p => p.id === action.penId);
        if (!pen) return state;
        const wheat = state.farm.inventory['WHEAT'] || 0;
        if (wheat >= 1) {
            return {
                ...state,
                farm: {
                    ...state.farm,
                    inventory: { ...state.farm.inventory, 'WHEAT': wheat - 1 },
                    pens: state.farm.pens.map(p => p.id === action.penId ? { ...p, feedLevel: Math.min(100, p.feedLevel + 50) } : p)
                }
            }
        }
        return state;
    }

    case 'COLLECT_ANIMAL_PRODUCE': {
        const pen = state.farm.pens.find(p => p.id === action.penId);
        if (!pen || pen.produceReady < 1) return state;
        
        const amount = Math.floor(pen.produceReady);
        const stats = ANIMAL_STATS[pen.type];
        const prodName = stats.produceName.toUpperCase();
        
        const totalItems = Object.values(state.farm.inventory).reduce((a, b) => a + b, 0);
        if (totalItems + amount > state.farm.inventoryLimit) return state;

        return {
            ...state,
            farm: {
                ...state.farm,
                inventory: { ...state.farm.inventory, [prodName]: (state.farm.inventory[prodName] || 0) + amount },
                pens: state.farm.pens.map(p => p.id === action.penId ? { ...p, produceReady: p.produceReady - amount } : p)
            }
        };
    }

    case 'START_INCUBATOR': {
        const eggs = state.farm.inventory['ЯЙЦО'] || 0;
        const batch = action.batchSize;
        if (eggs >= batch && !state.farm.incubator.isActive) {
            return {
                ...state,
                farm: {
                    ...state.farm,
                    inventory: { ...state.farm.inventory, 'ЯЙЦО': eggs - batch },
                    incubator: { 
                        isActive: true, 
                        startTime: state.time, 
                        timer: INCUBATOR_TIMER, 
                        ready: false, 
                        reward: null,
                        batchSize: batch
                    }
                }
            }
        }
        return state;
    }

    case 'OPEN_INCUBATOR': {
        if (!state.farm.incubator.ready) return state;

        const batchSize = state.farm.incubator.batchSize || 1;
        let newMoney = state.money;
        let newInventory = { ...state.farm.inventory };
        let newResources = { ...state.resources };

        let summary = { coins: 0, chicks: 0, food: 0, resource: 0, empty: 0 };

        // Probabilities based on batch size
        let probEmpty = 0.3;
        let probResource = 0.2; // 1-10 water or energy
        let probFood = 0.2;
        let probChick = 0.15;
        let probMoney = 0.15;

        if (batchSize === 5) {
             // 5 Eggs = Worse Odds for good stuff, higher empty
             probEmpty = 0.5;
             probResource = 0.2;
             probFood = 0.15;
             probChick = 0.05;
             probMoney = 0.1;
        } else if (batchSize === 10) {
            // 10 Eggs = Best Odds
            probEmpty = 0.1;
            probResource = 0.3;
            probFood = 0.3;
            probChick = 0.15;
            probMoney = 0.15;
        }

        for (let i = 0; i < batchSize; i++) {
            const roll = Math.random();
            let accumulatedChance = 0;

            accumulatedChance += probEmpty;
            if (roll < accumulatedChance) {
                summary.empty++;
                continue;
            }

            accumulatedChance += probResource;
            if (roll < accumulatedChance) {
                const amount = Math.floor(Math.random() * 10) + 1;
                if (Math.random() > 0.5) {
                    newResources.water = Math.min(newResources.maxWater, newResources.water + amount);
                } else {
                    newResources.energy = Math.min(newResources.maxEnergy, newResources.energy + amount);
                }
                summary.resource += amount;
                continue;
            }

            accumulatedChance += probMoney;
            if (roll < accumulatedChance) {
                const coins = Math.floor(Math.random() * 25) + 1;
                newMoney += coins;
                summary.coins += coins;
                continue;
            }
            
            accumulatedChance += probChick;
            if (roll < accumulatedChance) {
                 const name = NEW_ITEMS.CHICK.name.toUpperCase();
                 newInventory[name] = (newInventory[name] || 0) + 1;
                 summary.chicks++;
                 continue;
            }

            // Remainder is food
            const foodRoll = Math.random();
            let item;
            if (foodRoll < 0.30) item = NEW_ITEMS.PIE;
            else if (foodRoll < 0.60) item = NEW_ITEMS.OMELET;
            else if (foodRoll < 0.85) item = NEW_ITEMS.CHEESE;
            else item = NEW_ITEMS.BURGER; // Rare
            
            const name = item.name.toUpperCase();
            newInventory[name] = (newInventory[name] || 0) + 1;
            summary.food++;
        }

        let rewardParts = [];
        if (summary.coins > 0) rewardParts.push(`+${summary.coins} монет`);
        if (summary.chicks > 0) rewardParts.push(`+${summary.chicks} цып.`);
        if (summary.food > 0) rewardParts.push(`+${summary.food} еды`);
        if (summary.resource > 0) rewardParts.push(`+${summary.resource} рес.`);
        if (summary.empty > 0 && rewardParts.length === 0) rewardParts.push("Пусто");
        
        const rewardText = rewardParts.join(', ');

        return {
            ...state,
            money: newMoney,
            resources: newResources,
            farm: {
                ...state.farm,
                inventory: newInventory,
                incubator: { isActive: false, startTime: 0, timer: 0, ready: false, reward: rewardText, batchSize: 0 }
            }
        }
    }

    case 'CLAIM_QUEST': {
        const quest = state.quests.find(q => q.id === action.questId);
        if (quest && !quest.isClaimed && quest.progress >= quest.target) {
            return {
                ...state,
                money: state.money + quest.reward,
                quests: state.quests.map(q => q.id === action.questId ? { ...q, isClaimed: true } : q)
            }
        }
        return state;
    }

    case 'SELL_ITEM': {
        const current = state.farm.inventory[action.itemName] || 0;
        if (current < action.amount) return state;
        
        let price = 0;
        Object.values(CROP_STATS).forEach(s => { if(s.name.toUpperCase() === action.itemName) price = s.sellPrice });
        Object.values(ANIMAL_STATS).forEach(s => { if(s.produceName.toUpperCase() === action.itemName) price = s.producePrice });
        Object.values(NEW_ITEMS).forEach(s => { if(s.name.toUpperCase() === action.itemName) price = s.sellPrice });

        if (price === 0) return state; 

        // Quest: Earn
        const earned = price * action.amount;
        const updatedQuests = state.quests.map(q => 
            q.type === 'EARN' && !q.isClaimed ? { ...q, progress: Math.min(q.target, q.progress + earned) } : q
        );

        return {
            ...state,
            money: state.money + earned,
            quests: updatedQuests,
            farm: {
                ...state.farm,
                inventory: { ...state.farm.inventory, [action.itemName]: current - action.amount }
            }
        };
    }

    case 'UPGRADE_MACHINE': {
        const m = state.machines.find(x => x.id === action.id);
        if (!m) return state;
        
        let cost = 0;
        let newData = {};

        if (action.upgradeType === 'SPEED') {
            cost = UPGRADE_COSTS.SPEED * (m.levelSpeed + 1);
            newData = { levelSpeed: m.levelSpeed + 1 };
        } else if (action.upgradeType === 'ECO') {
            cost = UPGRADE_COSTS.ECO * (m.levelEco + 1);
            newData = { levelEco: m.levelEco + 1 };
        } else if (action.upgradeType === 'CAP') {
            cost = UPGRADE_COSTS.CAP * (m.levelCap + 1);
            newData = { levelCap: m.levelCap + 1 };
        }

        if (state.money >= cost) {
            return {
                ...state,
                money: state.money - cost,
                machines: state.machines.map(mach => mach.id === action.id ? { ...mach, ...newData } : mach)
            };
        }
        return state;
    }

    case 'TAKE_LOAN': {
        if (state.stats.loanActive) return state;
        return {
            ...state,
            money: state.money + 1000,
            stats: { ...state.stats, loanActive: true, loanDaysRemaining: 10 }
        };
    }
    
    case 'HIRE_STAFF': {
        const roleCost = 1000;
        if (state.money >= roleCost && !state.staff[action.role]) {
             return {
                 ...state,
                 money: state.money - roleCost,
                 staff: { ...state.staff, [action.role]: true }
             }
        }
        return state;
    }

    case 'REPAIR_GENERATOR': {
        if (state.money >= PRICES.REPAIR_GENERATOR) {
            return {
                ...state,
                money: state.money - PRICES.REPAIR_GENERATOR,
                generators: state.generators.map(g => g.id === action.id ? { ...g, health: 100 } : g)
            }
        }
        return state;
    }

    case 'UPGRADE_GENERATOR': {
        const gen = state.generators.find(g => g.id === action.id);
        if (!gen) return state;
        const cost = UPGRADE_COSTS.GENERATOR_BASE * gen.level;
        if (state.money >= cost) {
            // Upgrade increases level AND capacity
            const capacityIncrease = 50; 
            const newResources = { ...state.resources };
            
            if (gen.type === 'WATER') {
                newResources.maxWater += capacityIncrease;
            } else {
                newResources.maxEnergy += capacityIncrease;
            }

            return {
                ...state,
                money: state.money - cost,
                resources: newResources,
                generators: state.generators.map(g => g.id === action.id ? { ...g, level: g.level + 1 } : g)
            }
        }
        return state;
    }

    case 'BUY_FURNITURE': {
        const item = FURNITURE_ITEMS.find(i => i.id === action.itemId);
        if (item && state.money >= item.cost) {
            return {
                ...state,
                money: state.money - item.cost,
                stats: { ...state.stats, comfort: state.stats.comfort + item.comfort }
            }
        }
        return state;
    }

    case 'BUY_RESOURCE': {
        const cost = 100;
        const amount = 50;
        if (state.money >= cost) {
             const newRes = { ...state.resources };
             if (action.resource === 'WATER') {
                 newRes.water = Math.min(newRes.maxWater, newRes.water + amount);
             } else {
                 newRes.energy = Math.min(newRes.maxEnergy, newRes.energy + amount);
             }
             return {
                 ...state,
                 money: state.money - cost,
                 resources: newRes
             }
        }
        return state;
    }

    default:
      return state;
  }
};

const GameContext = createContext<{
  state: GameState;
  dispatch: React.Dispatch<Action>;
}>({ state: INITIAL_STATE, dispatch: () => {} });

export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(gameReducer, INITIAL_STATE);

  useEffect(() => {
    const timer = setInterval(() => {
      dispatch({ type: 'TICK' });
    }, TICK_RATE);
    return () => clearInterval(timer);
  }, []);

  return (
    <GameContext.Provider value={{ state, dispatch }}>
      {children}
    </GameContext.Provider>
  );
};

export const useGame = () => useContext(GameContext);
