
import { MachineType, CropType, AnimalType, TableType } from './types';

export const TICK_RATE = 1000; // 1 second real time
export const DAY_LENGTH_SECONDS = 300; // 5 minutes

export const PRICES = {
  WATER_UNIT: 2,
  ENERGY_UNIT: 2,
  REPAIR_GENERATOR: 50,
};

export const RESOURCE_MARKET = {
  WATER_PACK: { amount: 50, cost: 100 },
  ENERGY_PACK: { amount: 50, cost: 100 },
};

export const MACHINE_STATS = {
  [MachineType.WASHER_BASIC]: {
    cost: 500,
    cycleTime: 60,
    income: 80,
    water: 30,
    energy: 20,
    name: "Стирка Эконом",
    type: "washer"
  },
  [MachineType.WASHER_PRO]: {
    cost: 2500,
    cycleTime: 120,
    income: 250,
    water: 80,
    energy: 50,
    name: "Стирка Профи",
    type: "washer"
  },
  [MachineType.WASHER_ULTRA]: {
    cost: 6000,
    cycleTime: 180,
    income: 650,
    water: 120,
    energy: 90,
    name: "Стирка Ультра",
    type: "washer"
  },
  [MachineType.DRYER]: {
    cost: 600,
    cycleTime: 60,
    income: 90,
    water: 0,
    energy: 40,
    name: "Сушка База",
    type: "dryer"
  },
  [MachineType.DRYER_TURBO]: {
    cost: 3000,
    cycleTime: 90,
    income: 350,
    water: 0,
    energy: 100,
    name: "Сушка Турбо",
    type: "dryer"
  }
};

export const CROP_STATS = {
  [CropType.TOMATO]: { name: "Помидор", growthTime: 60, cost: 10, sellPrice: 25, isTree: false },
  [CropType.CUCUMBER]: { name: "Огурец", growthTime: 90, cost: 15, sellPrice: 40, isTree: false },
  [CropType.POTATO]: { name: "Картофель", growthTime: 120, cost: 20, sellPrice: 50, isTree: false },
  [CropType.CORN]: { name: "Кукуруза", growthTime: 150, cost: 30, sellPrice: 70, isTree: false },
  [CropType.STRAWBERRY]: { name: "Клубника", growthTime: 180, cost: 50, sellPrice: 100, isTree: false },
  [CropType.WHEAT]: { name: "Пшеница", growthTime: DAY_LENGTH_SECONDS, cost: 5, sellPrice: 0, isTree: false }, // Only for feed
  [CropType.APPLE_TREE]: { name: "Яблоня", growthTime: 200, cost: 150, sellPrice: 30, isTree: true, harvests: 5 },
  [CropType.MANGO_TREE]: { name: "Манго", growthTime: 250, cost: 200, sellPrice: 45, isTree: true, harvests: 7 },
};

export const ANIMAL_STATS = {
  [AnimalType.CHICKEN]: { cost: 200, feedConsume: 1, produceName: "Яйцо", producePrice: 15, cycle: 60, maxPerPen: 10 }, // Increased to 10
  [AnimalType.COW]: { cost: 1000, feedConsume: 5, waterConsume: 10, produceName: "Молоко", producePrice: 60, cycle: 60, maxPerPen: 2 },
};

export const TABLE_STATS = {
  [TableType.BASIC]: { cost: 800, eatingTime: 45, multiplier: 1.5, name: "Столик (Стандарт)" },
  [TableType.LUXURY]: { cost: 2500, eatingTime: 90, multiplier: 2.5, name: "VIP Ложа" },
}

export const BUILDING_COSTS = {
  COOP: 800,
  BARN: 2000,
};

export const PLOT_UNLOCK_COSTS = {
  plot_3: 1000,
  plot_4: 2500,
};

export const FURNITURE_ITEMS = [
  { id: 'plant', name: 'Фикус', cost: 200, comfort: 2 },
  { id: 'sofa', name: 'Диван (Кожа)', cost: 600, comfort: 5 },
  { id: 'vending', name: 'Вендинг', cost: 1200, comfort: 10 },
  { id: 'tv', name: '4K ТВ', cost: 2000, comfort: 15 },
];

export const UPGRADE_COSTS = {
  SPEED: 150,
  ECO: 200,
  CAP: 250,
  GENERATOR_BASE: 300,
};

export const DAILY_EXPENSES = {
  BASE: 50,
  STAFF_SALARY: 100, // Per hired staff
  LOAN_PAYMENT: 101,
};

export const QUESTS_DATA = [
  { id: 'q1', description: 'Стирка: Завершить 5 заказов', target: 5, reward: 200, type: 'WASH' },
  { id: 'q2', description: 'Ферма: Собрать 10 урожаев', target: 10, reward: 300, type: 'HARVEST' },
  { id: 'q3', description: 'Бизнес: Заработать $1000', target: 1000, reward: 150, type: 'EARN' }, // Progressive
];

export const INCUBATOR_TIMER = 10; // seconds

export const NEW_ITEMS = {
  CHICK: { name: "Цыпленок", sellPrice: 50 },
  OMELET: { name: "Омлет Шефа", sellPrice: 120 },
  PIE: { name: "Яблочный Пирог", sellPrice: 180 },
  CHEESE: { name: "Сыр", sellPrice: 90 },
  BURGER: { name: "Бургер", sellPrice: 150 },
  SUSHI: { name: "Суши Сет", sellPrice: 220 },
};
