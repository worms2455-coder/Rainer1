
export enum MachineType {
  WASHER_BASIC = 'WASHER_BASIC',
  WASHER_PRO = 'WASHER_PRO',
  WASHER_ULTRA = 'WASHER_ULTRA',
  DRYER = 'DRYER',
  DRYER_TURBO = 'DRYER_TURBO'
}

export enum MachineState {
  IDLE = 'IDLE',
  RUNNING = 'RUNNING',
  DONE = 'DONE', // Waiting for collection
  BROKEN = 'BROKEN'
}

export interface Machine {
  id: string;
  type: MachineType;
  state: MachineState;
  timer: number; // Remaining time in seconds
  maxTime: number; // Total cycle time
  levelSpeed: number;
  levelEco: number;
  levelCap: number;
}

export enum Weather {
  SUNNY = 'SUNNY',
  CLOUDY = 'CLOUDY',
  RAINY = 'RAINY'
}

export enum CropType {
  TOMATO = 'TOMATO',
  CUCUMBER = 'CUCUMBER',
  POTATO = 'POTATO',
  CORN = 'CORN',
  STRAWBERRY = 'STRAWBERRY',
  WHEAT = 'WHEAT',
  APPLE_TREE = 'APPLE_TREE',
  MANGO_TREE = 'MANGO_TREE'
}

export interface FarmPlot {
  id: string;
  crop: CropType | null;
  progress: number; // 0 to 100
  soilQuality: number; // 0 to 100
  isWatered: boolean;
  harvestsRemaining?: number; // For trees
  isLocked?: boolean;
}

export enum AnimalType {
  CHICKEN = 'CHICKEN',
  COW = 'COW'
}

export interface AnimalPen {
  id: string;
  type: AnimalType;
  count: number;
  feedLevel: number; // 0 to 100
  produceReady: number; // Amount of eggs/milk ready
}

export interface Generator {
  id: string;
  type: 'SOLAR' | 'WATER';
  level: number; // Affects output or storage
  health: number; // 0 to 100
}

export interface Staff {
  technician: boolean;
  receptionist: boolean;
  admin: boolean; // Auto-collect
  farmer: boolean; // Auto-farm
  chef: boolean;
}

export interface Quest {
  id: string;
  description: string;
  target: number;
  progress: number;
  reward: number;
  isClaimed: boolean;
  type: 'WASH' | 'HARVEST' | 'EARN';
}

export interface IncubatorState {
  isActive: boolean;
  startTime: number;
  timer: number;
  ready: boolean;
  reward?: string | null;
  batchSize?: number;
}

// --- RESTAURANT TYPES ---
export enum TableType {
  BASIC = 'BASIC',
  LUXURY = 'LUXURY'
}

export enum TableState {
  IDLE = 'IDLE',
  EATING = 'EATING',
  DIRTY = 'DIRTY'
}

export interface RestaurantTable {
  id: string;
  type: TableType;
  state: TableState;
  timer: number;
  currentDish: string | null;
  dishValue: number;
}

export interface GameState {
  money: number;
  day: number;
  time: number; // Seconds in current day (0 to 300)
  weather: Weather;
  
  resources: {
    water: number;
    maxWater: number;
    energy: number;
    maxEnergy: number;
  };

  machines: Machine[];
  generators: Generator[];
  
  farm: {
    plots: FarmPlot[];
    pens: AnimalPen[];
    inventory: Record<string, number>; // "WHEAT": 5, "EGG": 10
    inventoryLimit: number;
    incubator: IncubatorState;
  };

  restaurant: {
    tables: RestaurantTable[];
  };

  quests: Quest[];

  staff: Staff;
  
  stats: {
    totalWashes: number;
    comfort: number;
    loanActive: boolean;
    loanDaysRemaining: number;
  };
}
