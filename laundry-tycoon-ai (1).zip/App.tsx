
import React, { useState } from 'react';
import { GameProvider, useGame } from './context/GameContext';
import { LaundryView } from './components/views/LaundryView';
import { FarmView } from './components/views/FarmView';
import { ManagementView } from './components/views/ManagementView';
import { RestaurantView } from './components/views/RestaurantView';
import { Weather, Quest } from './types';
import { DAY_LENGTH_SECONDS } from './constants';
import { IsoCard } from './components/ui/IsoCard';

const AppContent: React.FC = () => {
  const { state, dispatch } = useGame();
  const [activeTab, setActiveTab] = useState<'laundry' | 'farm' | 'restaurant' | 'manage'>('laundry');
  const [showQuests, setShowQuests] = useState(false);

  // Time formatting
  const timePercent = (state.time / DAY_LENGTH_SECONDS) * 100;
  const gameHour = Math.floor((state.time / DAY_LENGTH_SECONDS) * 24); 
  const displayHour = (8 + gameHour) % 24; // Start day at 8 AM visually

  // Enhanced Atmosphere Backgrounds
  const bgClass = {
      [Weather.SUNNY]: "bg-[conic-gradient(at_top_right,_var(--tw-gradient-stops))] from-sky-400 via-sky-200 to-blue-100",
      [Weather.CLOUDY]: "bg-[conic-gradient(at_top_left,_var(--tw-gradient-stops))] from-gray-400 via-slate-300 to-slate-200",
      [Weather.RAINY]: "bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-700 via-slate-800 to-gray-900"
  }[state.weather];

  const pendingQuests = state.quests.filter(q => !q.isClaimed && q.progress >= q.target).length;

  return (
    <div className={`w-full h-screen overflow-hidden flex flex-col ${bgClass} transition-colors duration-1000 font-sans text-lg`}>
      {/* Top HUD */}
      <header className="px-4 pt-6 pb-2 shrink-0 z-50">
        <div className="bg-white/40 backdrop-blur-xl border border-white/50 rounded-2xl p-4 shadow-xl grid grid-cols-3 gap-4 items-center relative">
            
            {/* Left: Money & Time */}
            <div className="flex flex-col items-start">
                <span className="text-4xl font-black tracking-tighter text-slate-800 drop-shadow-sm flex items-center gap-1">
                    <span className="text-green-700">$</span>
                    {Math.floor(state.money).toLocaleString()}
                </span>
                <span className="text-xs font-bold uppercase tracking-widest text-slate-600 opacity-80 mt-1">
                    День {state.day} • {displayHour}:00
                </span>
            </div>

            {/* Center: Weather & Resources */}
            <div className="flex flex-col items-center justify-center">
                 <div className="flex items-center gap-4 mb-2 bg-white/50 px-4 py-1 rounded-full shadow-inner border border-white/40">
                    <div className="text-3xl animate-pulse filter drop-shadow">
                        {state.weather === Weather.SUNNY ? '☀️' : state.weather === Weather.CLOUDY ? '☁️' : '🌧️'}
                    </div>
                    <div className="h-6 w-px bg-slate-300"></div>
                    <div className="flex gap-3">
                         <div className="flex flex-col items-center">
                             <span className="text-[10px] font-bold text-blue-800">ВОДА</span>
                             <div className="w-16 h-4 bg-blue-200 rounded-full overflow-hidden border border-blue-300 relative">
                                 <div className="bg-blue-600 h-full transition-all duration-500" style={{ width: `${(state.resources.water/state.resources.maxWater)*100}%` }}></div>
                                 <div className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-blue-900 drop-shadow-sm">
                                     {Math.floor(state.resources.water)}/{state.resources.maxWater}
                                 </div>
                             </div>
                         </div>
                         <div className="flex flex-col items-center">
                             <span className="text-[10px] font-bold text-amber-800">ТОК</span>
                             <div className="w-16 h-4 bg-amber-200 rounded-full overflow-hidden border border-amber-300 relative">
                                 <div className="bg-amber-500 h-full transition-all duration-500" style={{ width: `${(state.resources.energy/state.resources.maxEnergy)*100}%` }}></div>
                                 <div className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-amber-900 drop-shadow-sm">
                                     {Math.floor(state.resources.energy)}/{state.resources.maxEnergy}
                                 </div>
                             </div>
                         </div>
                    </div>
                 </div>
            </div>

            {/* Right: Quest Button */}
            <div className="flex justify-end">
                <button 
                    onClick={() => setShowQuests(!showQuests)}
                    className="relative bg-white/80 hover:bg-white p-2 rounded-xl border border-white/60 shadow-lg transition-transform active:scale-95"
                >
                    <span className="text-3xl">📜</span>
                    {pendingQuests > 0 && (
                        <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold w-5 h-5 flex items-center justify-center rounded-full animate-bounce">
                            {pendingQuests}
                        </span>
                    )}
                </button>
            </div>
            
            {/* Time Progress Bar (Bottom Edge) */}
            <div className="absolute bottom-0 left-4 right-4 h-1 bg-slate-800/10 rounded-full overflow-hidden translate-y-2">
                <div className="h-full bg-slate-800 transition-all duration-1000 ease-linear" style={{ width: `${timePercent}%` }}></div>
            </div>
        </div>
      </header>

      {/* Quest Modal Overlay */}
      {showQuests && (
          <div className="absolute inset-0 z-[60] bg-black/40 backdrop-blur-sm flex items-center justify-center p-6">
              <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
                  <div className="bg-slate-100 p-4 border-b flex justify-between items-center">
                      <h3 className="font-black text-slate-700 text-xl">📋 Ежедневные Задачи</h3>
                      <button onClick={() => setShowQuests(false)} className="text-slate-400 hover:text-slate-600 text-2xl font-bold">×</button>
                  </div>
                  <div className="p-4 space-y-3">
                      {state.quests.map((q: Quest) => (
                          <div key={q.id} className={`p-3 rounded-xl border-2 flex justify-between items-center ${q.isClaimed ? 'bg-slate-50 border-slate-100 opacity-60' : 'bg-white border-blue-100'}`}>
                              <div>
                                  <div className="font-bold text-slate-800 text-sm">{q.description}</div>
                                  <div className="text-xs text-slate-500 mt-1">Прогресс: {Math.floor(q.progress)} / {q.target}</div>
                                  <div className="w-full bg-slate-100 h-1.5 rounded-full mt-1 w-32">
                                      <div className="bg-green-500 h-full rounded-full transition-all" style={{ width: `${Math.min(100, (q.progress/q.target)*100)}%` }}></div>
                                  </div>
                              </div>
                              <div>
                                  {q.isClaimed ? (
                                      <span className="text-xs font-bold text-green-600">✓ ГОТОВО</span>
                                  ) : (
                                      <button 
                                        disabled={q.progress < q.target}
                                        onClick={() => dispatch({ type: 'CLAIM_QUEST', questId: q.id })}
                                        className="bg-blue-500 text-white text-xs font-bold px-3 py-1.5 rounded-lg disabled:opacity-30 hover:bg-blue-600 shadow-sm transition-all"
                                      >
                                          +${q.reward}
                                      </button>
                                  )}
                              </div>
                          </div>
                      ))}
                      {state.quests.every(q => q.isClaimed) && (
                          <div className="text-center text-slate-400 py-4 italic text-sm">Все задания выполнены! Ждите завтра.</div>
                      )}
                  </div>
              </div>
          </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 overflow-hidden relative p-4 max-w-5xl mx-auto w-full">
        {activeTab === 'laundry' && <LaundryView />}
        {activeTab === 'farm' && <FarmView />}
        {activeTab === 'restaurant' && <RestaurantView />}
        {activeTab === 'manage' && <ManagementView />}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 w-full bg-white/80 backdrop-blur-xl border-t border-white/50 pb-8 pt-3 z-50 shadow-[0_-5px_20px_rgba(0,0,0,0.05)]">
        <div className="max-w-md mx-auto flex justify-around">
            <NavButton active={activeTab === 'laundry'} onClick={() => setActiveTab('laundry')} icon="🧼" label="Прачечная" />
            <NavButton active={activeTab === 'farm'} onClick={() => setActiveTab('farm')} icon="🌾" label="Ферма" />
            <NavButton active={activeTab === 'restaurant'} onClick={() => setActiveTab('restaurant')} icon="🍽️" label="Еда" />
            <NavButton active={activeTab === 'manage'} onClick={() => setActiveTab('manage')} icon="💼" label="Офис" />
        </div>
      </nav>
    </div>
  );
};

const NavButton = ({ active, onClick, icon, label }: any) => (
    <button 
        onClick={onClick}
        className={`
            relative flex flex-col items-center gap-1 px-4 py-2 rounded-2xl transition-all duration-300
            ${active 
                ? 'bg-slate-800 text-white shadow-xl -translate-y-2 scale-110' 
                : 'text-slate-500 hover:bg-slate-100 hover:-translate-y-1'
            }
        `}
    >
        <span className="text-2xl">{icon}</span>
        <span className="text-[11px] font-black uppercase tracking-wider">{label}</span>
        {active && <div className="absolute -bottom-1 w-1 h-1 bg-white rounded-full"></div>}
    </button>
);

const App: React.FC = () => {
  return (
    <GameProvider>
      <AppContent />
    </GameProvider>
  );
};

export default App;
